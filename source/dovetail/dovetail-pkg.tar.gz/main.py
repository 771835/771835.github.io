# coding=utf-8
"""主程序"""
import argparse
import os
import sys
import time
import traceback
from contextlib import chdir
from pathlib import Path
from typing import NoReturn, Optional

from dovetail.core.backend import BackendFactory
from dovetail.core.compile_config import CompileConfig
from dovetail.core.config import PROJECT_NAME, PROJECT_VERSION, \
    PROJECT_WEBSITE, PROJECT_LICENSE, IR_CACHE_FILE_PREFIX, COMMIT_HASH
from dovetail.core.enums.minecraft import MinecraftVersion
from dovetail.core.enums.optimization import OptimizationLevel
from dovetail.core.errors import CompilationError, report_count
from dovetail.core.errors import report, Errors
from dovetail.core.ir_builder import IRBuilder
from dovetail.core.optimize.optimizer import Optimizer
from dovetail.core.optimize.pass_registry import get_registry
from dovetail.core.parser.parser import parser_file
from dovetail.core.parser.visitor import ASTVisitor
from dovetail.plugins.plugin_loader.loader import plugin_loader
from dovetail.utils.annotations import timed
from dovetail.utils.ir_serializer import IRSymbolSerializer
from dovetail.utils.logger import get_logger, ThreadSafeLogger
from dovetail.utils.naming import NameDecorator
from dovetail.utils.resource import resolve_project_path, IS_COMPILED

logger = get_logger(__name__)


class Compiler:
    """
    编译 Dovetail 代码

    Attributes:
        config (CompileConfig): 编译器配置对象
        backend_name (str): 后端名(不填时自动选择)
        generate (bool): 生成指令
        output_temp_file (bool): 输出临时文件
    """

    def __init__(
            self,
            config: CompileConfig,
            backend_name: Optional[str] = None,
            generate: bool = True,
            output_temp_file: bool = False
    ):
        """
        初始化编译器

        Args:
            config (CompileConfig): 编译器配置对象
            backend_name (Optional[str]): 后端名(不填时自动选择)
            generate (bool): 是否生成指令
            output_temp_file (bool): 输出临时文件
        """
        self.config = config
        self.backend_name = backend_name
        self.generate = generate
        self.output_temp_file = output_temp_file

    def compile(self, source_path: Path, target_path: Path) -> int:
        """
        编译文件并生成数据包

        Args:
            source_path (Path): 源文件路径
            target_path (Path): 目标路径

        Returns:
            int: 编译结果状态码，0表示成功，非0表示失败
        """
        if source_path.exists():
            if source_path.is_file():
                return self._compile_file(source_path, target_path)
            else:
                logger.warning(
                    "使用 pack.config 的目录编译已经被弃用了，请使用 dovetail.toml 和 dovetail-build 工具代替。"
                    "参见 DFP-604 §4.1",
                )
                return 1
        else:
            report(
                Errors.FileNotFound,
                str(source_path),
                filepath=source_path,
                suggestion="仔细检查你的路径w",
            )
            return 2

    @timed("编译总用时: {:.3f}s")
    def _compile_file(
            self,
            source_path: Path,
            target_dir_path: Path,
            working_directory: Path | None = None
    ) -> int | NoReturn:
        """
        编译单个文件

        Args:
            source_path (Path): 源文件路径
            target_dir_path (Path): 目标目录路径
            working_directory (Optional[Path]): 工作目录路径，默认为源文件所在目录

        Returns:
            int: 编译结果状态码，0表示成功，非0表示失败
        """
        source_path = source_path.resolve()

        generator = ASTVisitor(self.config, source_path)

        with chdir(working_directory or source_path.parent):
            try:
                ast_tree = parser_file(source_path)

                if ast_tree is not None:
                    # if self.config.debug:
                    #     print("AST结构:")
                    #     print(ast_tree.pretty())
                    start_time = time.time()
                    generator.visit(ast_tree)
                    logger.info(f"AST遍历总用时: {time.time() - start_time:.3f}s")
                else:
                    return 3

                if report_count.peek() > 0:
                    logger.info("因报错中止编译")
                    return 4

                builder = self._optimize_ir(generator.builder)

                if report_count.peek() > 0:
                    logger.info("因报错中止编译")
                    return 5

                if self.config.debug:
                    print("最终IR:")
                    builder.print()

                if self.output_temp_file:
                    self._write_ir(builder, target_dir_path)

                if self.generate:
                    self._generate_backend_code(builder, target_dir_path)

            except CompilationError as e:
                # 预期的编译失败，记录结构化信息后返回错误码
                logger.critical(repr(e))
                if self.config.debug:
                    raise
                return 6

            except Exception:
                # 未预期的异常，重新抛出
                raise

        return 0

    @timed("写入临时文件用时{:.3f}s")
    def _write_ir(self, builder: IRBuilder, target_dir_path: Path):
        """
        写入 IR 序列

        Args:
            builder (IRBuilder): IR构建器
            target_dir_path (Path): 目标目录路径
        """
        temp_file = target_dir_path / f"{self.config.namespace}{IR_CACHE_FILE_PREFIX}"
        with open(temp_file, "wb") as f:
            f.write(IRSymbolSerializer.dump(builder))

    @timed("最终代码生成与写入用时{:.3f}s")
    def _generate_backend_code(self, builder: IRBuilder, target_path: Path):
        """
        生成后端代码

        Args:
            builder (IRBuilder): IR构建器
            target_path (Path): 目标目录路径
        """
        BackendFactory.auto_select(self.config, self.backend_name)(builder, target_path, self.config).generate()

    @timed("IR 优化用时 {:.3f}s")
    def _optimize_ir(self, builder: IRBuilder):
        """
        优化 IR

        Args:
            builder (IRBuilder): IR构建器
        """
        return Optimizer(builder, self.config).optimize()


def main():
    """
    主函数，负责解析参数并执行基本编译任务
    """

    if "--version" in sys.argv:
        import platform

        print(f"The version of {PROJECT_NAME} is {PROJECT_VERSION}")
        if COMMIT_HASH != "unknown":
            print(f"Commit: {COMMIT_HASH}")
        print(f"License: {PROJECT_LICENSE}")
        print(f"Repository: {PROJECT_WEBSITE}")
        print(f"Compiled: {IS_COMPILED}")
        print(f"Python version: {sys.version}")
        print(f"Platform:       {platform.platform()}")
        print(f"Architecture:   {platform.machine()}")
        print("")

        try:
            # 后加载插件，至少保证基本版本信息能被正常打印出来
            import dovetail.core.optimize.passes  # noqa
            ThreadSafeLogger.DISABLED = True
            plugin_loader.load_plugin("plugin_loader")

            if get_registry().get_all():
                print("OptimizationPass:")
                for pass_class in get_registry().get_all().values():
                    metadata = pass_class.get_metadata()
                    print(f"\t[{metadata.phase}] {metadata.display_name} ({metadata.name})")

            if not BackendFactory.is_empty():
                print("Backends:")
                for backend in BackendFactory.get_available_backends():
                    print(f"\t{backend}")
        except Exception as e:
            print(f"failed: {e}")
            if "--debug" in sys.argv:
                raise

        return

    parser = argparse.ArgumentParser(description="dovetail")

    parser.add_argument('input', type=str, help='输入文件路径')
    parser.add_argument('--minecraft-version', '-mcv', metavar='version', type=str, help='游戏版本', default="1.21.5")
    parser.add_argument('--output', '-o', metavar='path', type=str, help='输出文件路径')
    parser.add_argument('--lib-path', '-l', metavar='path', type=str, help='强制指定标准库路径')
    parser.add_argument('--include-dir','-I', metavar='path', action='append', help='添加搜索路径')
    parser.add_argument('--backend', '-b', metavar='name', type=str, help='强制指定后端名称', default="")
    parser.add_argument('--namespace', '-n', metavar='namespace', type=str, help='输出数据包命名空间')
    parser.add_argument('-O', metavar='level', type=int, choices=[0, 1, 2, 3], default=2, help='优化级别')
    parser.add_argument('--no-generate-commands', '-ngc', action='store_true', help='不生成指令')
    parser.add_argument('--output-temp-file', action='store_true', help='生成中间文件')
    parser.add_argument('--recursion', action='store_true', help='启用递归(需后端支持)')
    parser.add_argument('--disable-deprecated-function', action='store_true', help='禁用对已弃用函数编译')
    # args.add_argument('--first-class-functions', action='store_true',help='启用函数一等公民(所有代码都未适配，开不开都那样)')
    parser.add_argument('--experimental', action='store_true', help='启用扩展模式(测试性功能)')
    parser.add_argument('--disable-names-decorator', action='store_true', help='禁用命名修饰')
    parser.add_argument('--disable-plugins', action='store_true', help='禁用插件加载')
    parser.add_argument('--disable-info-logger', action='store_true', help='仅输出 warring 及以上的日志信息')
    parser.add_argument('--debug', action='store_true', help='启用调试模式')
    parser.add_argument('--version', action='store_true', help='显示版本后退出')

    parsed_args = parser.parse_args()

    # 解析路径
    entry = Path(parsed_args.input)
    target_path = Path(parsed_args.output or "target")

    # 加载插件
    if not parsed_args.disable_plugins:
        plugin_loader.load_plugin("plugin_loader")

    # 开启或关闭命名修饰
    NameDecorator.enable = not parsed_args.disable_names_decorator

    # 处理标准库路径
    if parsed_args.lib_path:
        lib_path = Path(parsed_args.lib_path).resolve()
    elif os.environ.get("DOVETAIL_LIB_PATH"):
        lib_path = Path(os.environ["DOVETAIL_LIB_PATH"]).resolve()
    else:
        lib_path = resolve_project_path("lib")

    if not lib_path.exists() or not lib_path.is_dir():
        logger.critical(f"标准库路径 '{lib_path}' 不存在或不是一个目录")
        return

    # 读取环境变量获得数据包描述
    description = os.environ.get("DOVETAIL_DESCRIPTION", "A datapack of Minecraft")

    compiler = Compiler(
        CompileConfig(
            parsed_args.namespace or "namespace",
            OptimizationLevel(parsed_args.O),
            MinecraftVersion.instance(parsed_args.minecraft_version),
            parsed_args.debug,
            parsed_args.recursion,
            False,
            parsed_args.disable_deprecated_function,
            parsed_args.experimental,
            lib_path,
            frozenset(Path(i).resolve() for i in parsed_args.include_dir) if parsed_args.include_dir else frozenset(),
            description
        ),
        parsed_args.backend,
        generate=not parsed_args.no_generate_commands,
        output_temp_file=parsed_args.output_temp_file
    )

    sys.exit(compiler.compile(entry, target_path))


if __name__ == "__main__":
    main()
