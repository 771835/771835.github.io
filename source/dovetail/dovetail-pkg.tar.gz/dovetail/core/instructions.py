# coding=utf-8
"""
IR 指令系统

核心原则：
1. 所有指令使用统一的 IRInstruction 类
2. 通过 opcode 区分指令类型
3. 使用工厂函数提供类型提示和自动补全
4. 可选的运行时验证（通过装饰器控制）
"""
from __future__ import annotations

import functools
from typing import Any, Optional, Union, get_type_hints, Callable

from dovetail.core.config import ENABLE_INSTRUCTION_VALIDATION, FAST_MODE
from dovetail.core.enums import PrimitiveDataType, StructureType, BinaryOps, CompareOps, UnaryOps
from dovetail.core.symbols import Variable, Literal, Reference, Function
from dovetail.core.symbols.class_ import Class
from dovetail.core.symbols.enumeration import Enumeration
from dovetail.core.symbols.structure import Structure
from dovetail.core.ir_code import InstructionFlag, InstructionCategory, IROpCode, IROpDescriptor  # noqa

_DefinableDataTypes = Union[
    PrimitiveDataType,
    Structure,
    Class,
    Enumeration
]

_CastableDataTypes = Union[
    PrimitiveDataType,
    Class,
]


# ==================== 验证系统 ====================


class ValidationError(Exception):
    """IR 指令验证错误"""
    pass


def validate_instruction(func):
    """
    指令验证装饰器

    根据函数签名的类型注解自动验证参数
    """

    if not FAST_MODE and ENABLE_INSTRUCTION_VALIDATION:
        # 获取函数签名的类型注解
        _type_hints = get_type_hints(func)
        _sig_keys = list(func.__annotations__.keys())
    else:
        return func

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # 验证参数
        for i, (param_name, arg) in enumerate(zip(_sig_keys, args)):
            expected_type = _type_hints.get(param_name)

            # 检查参数类型
            if expected_type is None:
                continue  # 如果没有类型注解，跳过

            # 处理 Optional 类型
            if getattr(expected_type, '__origin__', None) is Union:
                if arg is None:
                    continue  # 允许 None 值
                expected_types = expected_type.__args__
                if not any(isinstance(arg, t) for t in expected_types):
                    raise ValidationError(
                        f"{func.__name__}: 参数 '{param_name}' 期望类型 {expected_type}，"
                        f"实际得到 {type(arg)}"
                    )
            elif hasattr(expected_type, '__origin__'):
                # 处理其他泛型类型（如 List, Dict 等）
                if not isinstance(arg, expected_type.__origin__):
                    raise ValidationError(
                        f"{func.__name__}: 参数 '{param_name}' 期望类型 {expected_type}，"
                        f"实际得到 {type(arg)}"
                    )
            else:
                # 普通类型检查
                if not isinstance(arg, expected_type):  # NOQA
                    raise ValidationError(
                        f"{func.__name__}: 参数 '{param_name}' 期望类型 {expected_type}，"
                        f"实际得到 {type(arg)}"
                    )

        return func(*args, **kwargs)

    return wrapper


# ==================== 统一指令类 ====================

class IRInstruction:
    """
    统一的 IR 指令类

    所有指令都使用这个类，通过 opcode 区分类型
    """

    __slots__ = ('opcode', 'operands', '_hash_cache')

    def __init__(
            self,
            opcode: IROpDescriptor,
            *operands: Any,
    ):
        """
        创建 IR 指令

        Args:
            opcode: 操作码
            operands(list[Any]: 位置操作数
        """
        self.opcode = opcode

        self.operands = list(operands)

        self._hash_cache = None

    def __repr__(self) -> str:
        """
        默认的字符串表示

        可以通过注册自定义 repr 函数来覆盖
        """
        # 查找是否有注册的自定义 repr
        if self.opcode in _repr_registry:
            return _repr_registry[self.opcode](self)

        # 默认格式
        operands_str = ", ".join(str(op) for op in self.operands)
        return f"{self.opcode.desc}({operands_str})"

    def __hash__(self):
        if self._hash_cache is None:
            operand_hashes = []
            for op in self.operands:
                if isinstance(op, (list, tuple)):
                    operand_hashes.append(tuple(self._flatten_nested(op)))  # noqa
                elif isinstance(op, dict):
                    operand_hashes.append(
                        tuple(sorted((k, self._flatten_nested(v)) for k, v in op.items()))
                    )
                elif hasattr(op, '__hash__') and callable(op.__hash__):
                    try:
                        operand_hashes.append(hash(op))
                    except TypeError:
                        operand_hashes.append(id(op))
                else:
                    operand_hashes.append(id(op))

            self._hash_cache = hash((self.opcode, tuple(operand_hashes)))

        return self._hash_cache

    def __eq__(self, other: Any):
        if not isinstance(other, IRInstruction):
            return False
        if self.opcode != other.opcode:
            return False
        if len(self.operands) != len(other.operands):
            return False
        return all(a == b for a, b in zip(self.operands, other.operands))

    def _flatten_nested(self, obj) -> tuple | int:
        """递归处理嵌套结构"""
        if isinstance(obj, (list, tuple)):
            return tuple(self._flatten_nested(item) for item in obj)
        elif isinstance(obj, dict):
            return tuple(sorted((k, self._flatten_nested(v)) for k, v in obj.items()))
        elif hasattr(obj, '__hash__') and callable(obj.__hash__):
            try:
                return hash(obj)
            except TypeError:
                return id(obj)
        return id(obj)

    def get_operands(self) -> list:
        """获取操作数列表"""
        return self.operands

    def get_opcode(self) -> IROpDescriptor:
        """获取操作码"""
        return self.opcode


# ==================== Repr 注册系统 ====================

_repr_registry: dict[IROpDescriptor, Callable] = {}


def register_repr(opcode: IROpDescriptor):
    """
    注册自定义 repr 函数的装饰器

    Args:
        opcode: 要注册的操作码

    Returns:
        装饰器函数
    """

    def decorator(func):
        _repr_registry[opcode] = func
        return func

    return decorator


# ==================== 控制流指令 ====================

@validate_instruction
def IRJump(scope: str) -> IRInstruction:
    """
    跳转指令

    Args:
        scope: 目标作用域名称

    Returns:
        跳转指令
    """
    return IRInstruction(IROpCode.JUMP, scope)


@register_repr(IROpCode.JUMP)
def _jump_repr(instr: IRInstruction) -> str:
    return f"goto {instr.operands[0]}"


@validate_instruction
def IRCondJump(
        condition: Reference[Variable | Literal],
        true_scope: Optional[str] = None,
        false_scope: Optional[str] = None
) -> IRInstruction:
    """
    条件跳转指令

    Args:
        condition: 条件变量或字面量（必须是布尔类型）
        true_scope: 条件为真时的目标作用域
        false_scope: 条件为假时的目标作用域

    Returns:
        条件跳转指令

    Raises:
        ValidationError: 如果条件不是布尔类型
    """
    # 类型验证
    if not FAST_MODE and ENABLE_INSTRUCTION_VALIDATION:
        if not PrimitiveDataType.BOOLEAN.is_subclass_of(condition.dtype):
            raise ValidationError(
                f"条件跳转要求布尔类型，实际得到 {condition.dtype}"
            )

    return IRInstruction(IROpCode.COND_JUMP, condition, true_scope, false_scope)


@register_repr(IROpCode.COND_JUMP)
def _cond_jump_repr(instr: IRInstruction) -> str:
    if len(instr.operands) < 3:
        print(instr.operands)
    cond = (instr.operands[0].value
            if isinstance(instr.operands[0], Literal)
            else instr.operands[0].get_name())
    true_label = instr.operands[1]
    false_label = instr.operands[2]

    if false_label:
        return f"if {cond} goto {true_label} else goto {false_label}"
    else:
        return f"if {cond} goto {true_label}"


@validate_instruction
def IRFunction(function: Function) -> IRInstruction:
    """
    函数定义指令

    Args:
        function: 函数符号对象

    Returns:
        函数定义指令
    """
    return IRInstruction(IROpCode.FUNCTION, function)


@register_repr(IROpCode.FUNCTION)
def _function_repr(instr: IRInstruction) -> str:
    func: Function = instr.operands[0]
    params_str = ", ".join(
        f"{p.var.dtype.get_name()} {p.var.get_name()}"
        for p in func.params
    )
    annotations_str = "\n".join(f"@{name}{attachment}" for name, attachment in func.annotations.items())
    return f"{annotations_str}\nfunction {func.return_type.get_name()} {func.get_name()}({params_str})"


@validate_instruction
def IRCall(
        result: Optional[Variable],
        function: Function,
        arguments: dict[str, Reference]
) -> IRInstruction:
    """
    函数调用指令

    Args:
        result: 返回值存储变量（如果函数返回 void 则为 None）
        function: 被调用的函数对象
        arguments: 参数字典，键为参数名，值为 Reference 对象

    Returns:
        函数调用指令
    """
    return IRInstruction(IROpCode.CALL, result, function, arguments)


@register_repr(IROpCode.CALL)
def _call_repr(instr: IRInstruction) -> str:
    result = instr.operands[0]
    func: Function = instr.operands[1]
    args: dict[str, Reference] = instr.operands[2]

    args_str = ", ".join(f"{name}={val}" for name, val in args.items())

    if result:
        return f"{result.get_name()} = {func.get_name()}({args_str})"
    else:
        return f"{func.get_name()}({args_str})"


@validate_instruction
def IRReturn(value: Optional[Reference] = None) -> IRInstruction:
    """
    返回指令

    Args:
        value: 返回值（可选，void 函数为 None）

    Returns:
        返回指令
    """
    return IRInstruction(IROpCode.RETURN, value)


@register_repr(IROpCode.RETURN)
def _return_repr(instr: IRInstruction) -> str:
    if instr.operands[0] is None:
        return "return"

    value = instr.operands[0]

    return f"return {value}"


@validate_instruction
def IRScopeBegin(name: str, scope_type: StructureType) -> IRInstruction:
    """
    作用域开始指令

    Args:
        name: 作用域名称
        scope_type: 作用域类型（来自 StructureType 枚举）

    Returns:
        作用域开始指令
    """
    return IRInstruction(IROpCode.SCOPE_BEGIN, name, scope_type)


@register_repr(IROpCode.SCOPE_BEGIN)
def _scope_begin_repr(instr: IRInstruction) -> str:
    return f"scope {instr.operands[0]} ({instr.operands[1].name}) {{"


@validate_instruction
def IRScopeEnd(name: str, scope_type: StructureType) -> IRInstruction:
    """
    作用域结束指令

    Args:
        name: 作用域名称
        scope_type: 作用域类型（来自 StructureType 枚举）

    Returns:
        作用域结束指令
    """
    return IRInstruction(IROpCode.SCOPE_END, name, scope_type)


@register_repr(IROpCode.SCOPE_END)
def _scope_end_repr(instr: IRInstruction) -> str:
    return f"}} // end scope {instr.operands[0]}"


@validate_instruction
def IRBreak(scope: str) -> IRInstruction:
    """
    中断指令（跳出循环）

    Args:
        scope: 目标循环作用域名称

    Returns:
        中断指令
    """
    return IRInstruction(IROpCode.BREAK, scope)


@register_repr(IROpCode.BREAK)
def _break_repr(instr: IRInstruction) -> str:
    return f"break to {instr.operands[0]}"


@validate_instruction
def IRContinue(scope: str) -> IRInstruction:
    """
    继续指令（跳到循环开始）

    Args:
        scope: 目标循环作用域名称

    Returns:
        继续指令
    """
    return IRInstruction(IROpCode.CONTINUE, scope)


@register_repr(IROpCode.CONTINUE)
def _continue_repr(instr: IRInstruction) -> str:
    return f"continue to {instr.operands[0]}"


# ==================== 数据操作指令 ====================

@validate_instruction
def IRDeclare(variable: Variable) -> IRInstruction:
    """
    变量声明指令

    Args:
        variable: 要声明的变量对象

    Returns:
        声明指令
    """
    return IRInstruction(IROpCode.DECLARE, variable)


@register_repr(IROpCode.DECLARE)
def _declare_repr(instr: IRInstruction) -> str:
    var: Variable = instr.operands[0]
    return f"declare {var.dtype.get_name()} {var.get_name()}"


@validate_instruction
def IRAssign(
        target: Variable,
        source: Reference
) -> IRInstruction:
    """
    赋值指令

    Args:
        target: 目标变量
        source: 赋值来源（Reference）

    Returns:
        赋值指令
    """
    return IRInstruction(IROpCode.ASSIGN, target, source)


@register_repr(IROpCode.ASSIGN)
def _assign_repr(instr: IRInstruction) -> str:
    target: Variable = instr.operands[0]
    source = instr.operands[1]

    return f"{target.get_name()} = {source}"


@validate_instruction
def IRUnaryOp(
        result: Variable,
        op: UnaryOps,
        operand: Reference
) -> IRInstruction:
    """
    一元运算指令

    Args:
        result: 结果变量
        op: 一元运算符（来自 UnaryOps 枚举，如 NOT、NEG）
        operand: 操作数

    Returns:
        一元运算指令
    """
    return IRInstruction(IROpCode.UNARY_OP, result, op, operand)


@register_repr(IROpCode.UNARY_OP)
def _unary_op_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    op: UnaryOps = instr.operands[1]
    operand: Reference = instr.operands[2]

    return f"{result.get_name()} = {op.value}{operand}"


@validate_instruction
def IRBinaryOp(
        result: Variable,
        op: BinaryOps,
        left: Reference,
        right: Reference
) -> IRInstruction:
    """
    二元运算指令

    Args:
        result: 结果变量
        op: 二元运算符（来自 BinaryOps 枚举，如 ADD、SUB、MUL、DIV、MOD）
        left: 左操作数
        right: 右操作数

    Returns:
        二元运算指令
    """
    return IRInstruction(IROpCode.BINARY_OP, result, op, left, right)


@register_repr(IROpCode.BINARY_OP)
def _binary_op_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    op: BinaryOps = instr.operands[1]
    left: Reference = instr.operands[2]
    right: Reference = instr.operands[3]

    return f"{result.get_name()} = {left} {op.value} {right}"


@validate_instruction
def IRCompare(
        result: Variable,
        op: CompareOps,
        left: Reference,
        right: Reference
) -> IRInstruction:
    """
    比较指令

    Args:
        result: 结果变量（必须是布尔类型）
        op: 比较运算符（来自 CompareOps 枚举，如 EQ、NE、LT、GT、LE、GE）
        left: 左操作数
        right: 右操作数

    Returns:
        比较指令

    Raises:
        ValidationError: 如果结果变量不是布尔类型
    """
    if not FAST_MODE and ENABLE_INSTRUCTION_VALIDATION and result.dtype != PrimitiveDataType.BOOLEAN:
        raise ValidationError(f"比较结果必须是布尔类型，实际得到 {result.dtype}")

    return IRInstruction(IROpCode.COMPARE, result, op, left, right)


@register_repr(IROpCode.COMPARE)
def _compare_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    op: CompareOps = instr.operands[1]
    left: Reference = instr.operands[2]
    right: Reference = instr.operands[3]

    return f"{result.get_name()} = {left} {op.value} {right}"


@validate_instruction
def IRCast(
        result: Variable,
        target_type: _CastableDataTypes,
        source: Reference
) -> IRInstruction:
    """
    类型转换指令

    Args:
        result: 结果变量
        source: 源值
        target_type: 目标类型（PrimitiveDataType 或其他类型对象）

    Returns:
        类型转换指令
    """
    return IRInstruction(IROpCode.CAST, result, target_type, source)


@register_repr(IROpCode.CAST)
def _cast_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    target_type = instr.operands[1]
    source: Reference = instr.operands[2]

    return f"{result.get_name()} = cast<{target_type!r}>({source})"


@validate_instruction
def IRFree(variable: Variable) -> IRInstruction:
    """
    释放变量指令

    Args:
        variable: 要释放的变量

    Returns:
        释放指令
    """
    return IRInstruction(IROpCode.FREE, variable)


@register_repr(IROpCode.FREE)
def _free_repr(instr: IRInstruction) -> str:
    var: Variable = instr.operands[0]
    return f"free {var.get_name()}"


@validate_instruction
def IRCompute(result: Variable, provider_tree: dict, integer: bool = True) -> IRInstruction:
    """
    数值提供器计算指令

    Args:
        result:        结果存储变量
        provider_tree: 语义化表达式树，例如:
            {"op": "sum", "args": [ref_a, ref_b, {"op": "product", "args": [ref_c, 3]}]}
            Reference 叶节点 = 变量/常量引用
            int/float    = 内部常量（如 -1）
            dict         = 嵌套子表达式
        integer:       整数模式（True = 每步截断，False = 浮点模式）
                       当前 Dovetail 只有整数，默认 True
    """
    return IRInstruction(IROpCode.COMPUTE, result, provider_tree, integer)


@register_repr(IROpCode.COMPUTE)
def _compute_repr(instr: IRInstruction) -> str:
    result = instr.operands[0].get_name()
    tree = instr.operands[1]
    integer = instr.operands[2]
    mode = "int" if integer else "float"
    return f"{result} = COMPUTE.{mode} -> {_tree_to_str(tree)}"


def _tree_to_str(node) -> str:
    """递归把语义 dict 转成可读伪代码"""
    if isinstance(node, (int, float)):
        return str(node)
    if isinstance(node, Reference):
        return node.get_name()
    if isinstance(node, dict):
        op = node.get("op", "?")
        args = node.get("args", [])
        args_str = ", ".join(_tree_to_str(a) for a in args)
        return f"{op}({args_str})"
    return str(node)

# ==================== 面向对象指令 ====================

@validate_instruction
def IRClass(class_symbol: Class) -> IRInstruction:
    """
    类定义指令

    Args:
        class_symbol: 类符号对象

    Returns:
        类定义指令
    """
    return IRInstruction(IROpCode.CLASS, class_symbol)


@register_repr(IROpCode.CLASS)
def _class_repr(instr: IRInstruction) -> str:
    cls: Class = instr.operands[0]
    return f"class {cls.get_name()}"


@validate_instruction
def IRNewObj(
        result: Variable,
        class_type: Class,
        arguments: dict[str, Reference]
) -> IRInstruction:
    """
    新建对象指令

    Args:
        result: 结果变量（存储对象引用）
        class_type: 类类型对象
        arguments: 构造函数参数字典，键为参数名，值为 Reference 对象

    Returns:
        新建对象指令
    """
    return IRInstruction(IROpCode.NEW_OBJ, result, class_type, arguments)


@register_repr(IROpCode.NEW_OBJ)
def _new_obj_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    class_type: Class = instr.operands[1]
    args: dict = instr.operands[2]

    args_str = ", ".join(f"{name}={val}" for name, val in args.items())

    return f"{result.get_name()} = new {class_type.get_name()}({args_str})"


@validate_instruction
def IRGetProperty(
        result: Variable,
        object_ref: Reference,
        property_name: str
) -> IRInstruction:
    """
    获取属性指令

    Args:
        result: 结果变量（存储属性值）
        object_ref: 对象引用
        property_name: 属性名称

    Returns:
        获取属性指令
    """
    return IRInstruction(IROpCode.GET_PROPERTY, result, object_ref, property_name)


@register_repr(IROpCode.GET_PROPERTY)
def _get_property_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    obj_ref: Reference = instr.operands[1]
    prop_name: str = instr.operands[2]

    return f"{result.get_name()} = {obj_ref}.{prop_name}"


@validate_instruction
def IRSetProperty(
        object_ref: Reference,
        property_name: str,
        value: Reference
) -> IRInstruction:
    """
    设置属性指令

    Args:
        object_ref: 对象引用
        property_name: 属性名称
        value: 新值

    Returns:
        设置属性指令
    """
    return IRInstruction(IROpCode.SET_PROPERTY, object_ref, property_name, value)


@register_repr(IROpCode.SET_PROPERTY)
def _set_property_repr(instr: IRInstruction) -> str:
    obj_ref: Reference = instr.operands[0]
    prop_name: str = instr.operands[1]
    value: Reference = instr.operands[2]

    return f"{obj_ref}.{prop_name} = {value}"


@validate_instruction
def IRCallMethod(
        result: Optional[Variable],
        object_ref: Reference,
        method: Function,
        arguments: dict[str, Reference]
) -> IRInstruction:
    """
    调用方法指令

    Args:
        result: 返回值存储变量（void 方法为 None）
        object_ref: 对象引用
        method: 方法
        arguments: 方法参数字典，键为参数名，值为 Reference 对象

    Returns:
        调用方法指令
    """
    return IRInstruction(IROpCode.CALL_METHOD, result, object_ref, method, arguments)


@register_repr(IROpCode.CALL_METHOD)
def _call_method_repr(instr: IRInstruction) -> str:
    result: Optional[Variable] = instr.operands[0]
    obj_ref: Reference = instr.operands[1]
    method_name: str = instr.operands[2]
    args: dict = instr.operands[3]

    args_str = ", ".join(f"{name}={val}" for name, val in args.items())

    call_str = f"{obj_ref}.{method_name}({args_str})"

    if result:
        return f"{result} = {call_str}"
    else:
        return call_str


@validate_instruction
def IRFreeObj(object_ref: Reference) -> IRInstruction:
    """
    释放对象指令

    Args:
        object_ref: 要释放的对象引用

    Returns:
        释放对象指令
    """
    return IRInstruction(IROpCode.FREE_OBJ, object_ref)


@register_repr(IROpCode.FREE_OBJ)
def _free_obj_repr(instr: IRInstruction) -> str:
    obj_ref: Reference = instr.operands[0]
    return f"free {obj_ref}"


@validate_instruction
def IRIndexGet(
        result: Variable,
        container: Reference,
        key: Reference
) -> IRInstruction:
    """
    索引读取指令

    适用于 ListType 和 DictType：
    - container 是 ListType → key 必须是 int → /data get ... [index]
    - container 是 DictType → key 必须是 string → /data get ... .key

    Args:
        result: 结果变量
        container: 容器（ListType 或 DictType）
        key: 索引或键

    Returns:
        索引读取指令
    """
    return IRInstruction(IROpCode.INDEX_GET, result, container, key)


@register_repr(IROpCode.INDEX_GET)
def _index_get_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    container: Reference = instr.operands[1]
    key: Reference = instr.operands[2]
    return f"{result.get_name()} = {container}[{key!r}]"


@validate_instruction
def IRIndexSet(
        container: Reference,
        key: Reference,
        value: Reference
) -> IRInstruction:
    """
    索引写入指令

    适用于 ListType 和 DictType，后端根据 container.dtype 决定生成命令。

    Args:
        container: 容器（ListType 或 DictType）
        key: 索引或键
        value: 写入的值

    Returns:
        索引写入指令
    """
    return IRInstruction(IROpCode.INDEX_SET, container, key, value)


@register_repr(IROpCode.INDEX_SET)
def _index_set_repr(instr: IRInstruction) -> str:
    container: Reference = instr.operands[0]
    key: Reference = instr.operands[1]
    value: Reference = instr.operands[2]
    return f"{container}[{key!r}] = {value}"


@validate_instruction
def IRContainerLen(result: Variable, container: Reference) -> IRInstruction:
    """
    获取容器长度指令

    Args:
        result: 结果变量（int 类型）
        container: 容器（ListType 或 DictType）

    Returns:
        获取长度指令
    """
    return IRInstruction(IROpCode.CONTAINER_LEN, result, container)


@register_repr(IROpCode.CONTAINER_LEN)
def _container_len_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    container: Reference = instr.operands[1]
    return f"{result.get_name()} = len({container})"


@validate_instruction
def IRListAppend(container: Reference, value: Reference) -> IRInstruction:
    """
    追加元素指令（仅 ListType）

    Args:
        container: 列表容器
        value: 要追加的值

    Returns:
        追加指令
    """
    return IRInstruction(IROpCode.LIST_APPEND, container, value)


@register_repr(IROpCode.LIST_APPEND)
def _list_append_repr(instr: IRInstruction) -> str:
    container: Reference = instr.operands[0]
    value: Reference = instr.operands[1]
    return f"{container}.append({value})"


@validate_instruction
def IRDictHas(result: Variable, container: Reference, key: Reference) -> IRInstruction:
    """
    检查键是否存在指令（仅 DictType）

    Args:
        result: 结果变量（boolean 类型）
        container: 字典容器
        key: 要检查的键

    Returns:
        检查键指令
    """
    return IRInstruction(IROpCode.DICT_HAS, result, container, key)


@register_repr(IROpCode.DICT_HAS)
def _dict_has_repr(instr: IRInstruction) -> str:
    result: Variable = instr.operands[0]
    container: Reference = instr.operands[1]
    key: Reference = instr.operands[2]
    return f"{result.get_name()} = {key!r} in {container}"


@validate_instruction
def IRDictRemove(container: Reference, key: Reference) -> IRInstruction:
    """
    删除键指令（仅 DictType）

    Args:
        container: 字典容器
        key: 要删除的键

    Returns:
        删除键指令
    """
    return IRInstruction(IROpCode.DICT_REMOVE, container, key)


@register_repr(IROpCode.DICT_REMOVE)
def _dict_remove_repr(instr: IRInstruction) -> str:
    container: Reference = instr.operands[0]
    key: Reference = instr.operands[1]
    return f"{container}.remove({key!r})"


# ==================== 结构体指令 ====================

@validate_instruction
def IRStructDef(structure: Structure) -> IRInstruction:
    """
    结构体定义指令

    Args:
        structure: 结构体符号对象（含 fields + methods）

    Returns:
        结构体定义指令
    """
    return IRInstruction(IROpCode.STRUCT_DEF, structure)


@register_repr(IROpCode.STRUCT_DEF)
def _struct_def_repr(instr: IRInstruction) -> str:
    s: Structure = instr.operands[0]
    fields_str = ", \n".join(f"{dtype.get_name()} {name}" for name, dtype in s.fields.items())
    return f"struct {s.get_name()} {{ {fields_str} }}"


@validate_instruction
def IRStructNew(
        result: Variable,
        structure: Structure,
        field_values: dict[str, Reference]
) -> IRInstruction:
    """
    结构体实例化指令

    Args:
        result:       存储实例的变量（类型为 Structure）
        structure:    结构体类型
        field_values: 字段初始值 {字段名: 引用}

    Returns:
        结构体实例化指令
    """
    return IRInstruction(IROpCode.STRUCT_NEW, result, structure, field_values)


@register_repr(IROpCode.STRUCT_NEW)
def _struct_new_repr(instr: IRInstruction) -> str:
    result = instr.operands[0]
    s: Structure = instr.operands[1]
    vals: dict = instr.operands[2]
    fields_str = ", ".join(f".{name}={val}" for name, val in vals.items())
    return f"{result.get_name()} = {s.get_name()}{{{fields_str}}}"


@validate_instruction
def IRStructGet(
        result: Variable,
        instance: Reference,
        field: str
) -> IRInstruction:
    """
    结构体字段读取指令

    Args:
        result:   存储字段值的变量
        instance: 结构体实例引用
        field:    字段名

    Returns:
        字段读取指令
    """
    return IRInstruction(IROpCode.STRUCT_GET, result, instance, field)


@register_repr(IROpCode.STRUCT_GET)
def _struct_get_repr(instr: IRInstruction) -> str:
    result = instr.operands[0]
    instance = instr.operands[1]
    field = instr.operands[2]
    return f"{result.get_name()} = {instance}.{field}"


@validate_instruction
def IRStructSet(
        instance: Reference,
        field: str,
        value: Reference
) -> IRInstruction:
    """
    结构体字段写入指令

    Args:
        instance: 结构体实例引用
        field:    字段名
        value:    写入值

    Returns:
        字段写入指令
    """
    return IRInstruction(IROpCode.STRUCT_SET, instance, field, value)


@register_repr(IROpCode.STRUCT_SET)
def _struct_set_repr(instr: IRInstruction) -> str:
    instance = instr.operands[0]
    field = instr.operands[1]
    value = instr.operands[2]
    return f"{instance}.{field} = {value}"


@validate_instruction
def IRStructCall(
        result: Optional[Variable],
        instance: Reference,
        method: Function,
        arguments: dict[str, Reference]
) -> IRInstruction:
    """
    结构体方法调用指令

    Args:
        result:    返回值变量（void 方法为 None）
        instance:  结构体实例引用（作为 self 传入）
        method:    方法函数对象
        arguments: 实参字典

    Returns:
        方法调用指令
    """
    return IRInstruction(IROpCode.STRUCT_CALL, result, instance, method, arguments)


@register_repr(IROpCode.STRUCT_CALL)
def _struct_call_repr(instr: IRInstruction) -> str:
    result = instr.operands[0]
    instance = instr.operands[1]
    method: Function = instr.operands[2]
    args: dict = instr.operands[3]
    args_str = ", ".join(f"{name}={val}" for name, val in args.items())
    if result:
        return f"{result.get_name()} = {instance}.{method.get_name()}({args_str})"
    return f"{instance}.{method.get_name()}({args_str})"


@validate_instruction
def IRStructFree(instance: Reference) -> IRInstruction:
    """
    结构体释放指令

    Args:
        instance: 要释放的结构体实例引用

    Returns:
        释放指令
    """
    return IRInstruction(IROpCode.STRUCT_FREE, instance)


@register_repr(IROpCode.STRUCT_FREE)
def _struct_free_repr(instr: IRInstruction) -> str:
    return f"free {instr.operands[0]}"
