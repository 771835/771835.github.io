# coding=utf-8
"""
常量折叠 Pass

在编译时计算常量表达式，减少运行时计算开销。
支持控制流敏感的常量传播分析。
"""
from __future__ import annotations

from enum import Enum, auto
from typing import Any, Set, Optional

from attrs import define, field

from dovetail.core.compile_config import CompileConfig
from dovetail.core.enums import OptimizationLevel, BinaryOps, CompareOps, UnaryOps, StructureType, PrimitiveDataType
from dovetail.core.enums.types import ValueType
from dovetail.core.instructions import IROpCode, IRCall, IRAssign, IRJump, IRInstruction, IRReturn, IRCompute
from dovetail.core.ir_builder import IRBuilder, IRBuilderIterator
from dovetail.core.optimize.base import IROptimizationPass
from dovetail.core.optimize.pass_metadata import PassMetadata, PassPhase
from dovetail.core.optimize.pass_registry import register_pass
from dovetail.core.symbols import Variable, Literal, Reference, Function, Class
from dovetail.utils.constant_operator_handlers import COMPARE_OP_HANDLERS, BINARY_OP_HANDLERS, UNARY_OP_HANDLERS, \
    number_to_int32

# multi-arg 求值器
_MULTI_ARG_EVAL = {
    "add": lambda args: sum(args),
    "mul": lambda args: _product(args),
    "min": lambda args: min(args),
    "max": lambda args: max(args),
    "avg": lambda args: sum(args) / len(args) if args else 0,
    "length": lambda args: sum(a * a for a in args) ** 0.5,
}

# binary 求值器：键为 mc_type（不含 minecraft: 前缀）
_BINARY_EVAL = {
    "sub": lambda l, r: l - r,
    "div": lambda l, r: int(l / r) if r != 0 else None,  # 向零截断
    "mod": lambda l, r: int(l % r) if r != 0 else None,  # 向零截断
    "floor_div": lambda l, r: l // r if r != 0 else None,
    "floor_mod": lambda l, r: l % r if r != 0 else None,
    "pow": lambda l, r: l ** r if r >= 0 else None,
}

# unary 求值器
_UNARY_EVAL = {
    "abs": lambda v: abs(v),
    "negate": lambda v: -v,
    "from_int": lambda v: float(v),
    "from_float": lambda v: int(v),  # 向零截断
    "sqrt": lambda v: v ** 0.5 if v >= 0 else None,
    "sin": lambda v: __import__("math").sin(v),
    "cos": lambda v: __import__("math").cos(v),
    "floor": lambda v: __import__("math").floor(v),
    "ceil": lambda v: __import__("math").ceil(v),
    "round": lambda v: round(v),
    "truncate": lambda v: int(v),
}


def _product(args):
    r = 1
    for a in args:
        r *= a
    return r


def _product(args):
    r = 1
    for a in args:
        r *= a
    return r


@register_pass(PassMetadata(
    name="constant_folding",
    display_name="常量折叠",
    description="在编译时计算常量表达式，支持控制流敏感分析",
    level=OptimizationLevel.O1,
    phase=PassPhase.TRANSFORM,
    provided_features=("simplified_arithmetic",)
))
class ConstantFoldingPass(IROptimizationPass):
    """
    常量折叠优化 Pass

    核心策略：
    1. 顺序遍历 IR，维护符号表
    2. 遇到 CONDITION 作用域时，保存当前状态
    3. 在条件分支内使用临时符号表
    4. 遇到 COND_JUMP 时，合并所有分支的状态
    5. 循环作用域结束时，向上传播被修改的变量为 UNKNOWN（防止变量遮蔽导致错误折叠）
    """

    class FoldingFlags(Enum):
        """常量折叠标志"""
        UNKNOWN = auto()  # 未知/无法追踪变量
        UNDEFINED = auto()  # 未定义的变量

    @define(slots=True)
    class SymbolTable:
        """
        支持父-子结构的符号表。
        在当前作用域及其祖先作用域中查找符号。
        """
        name: str = field()
        stype: StructureType = field()
        table: dict[str, Reference | ConstantFoldingPass.FoldingFlags] = field(factory=dict)
        parent: "ConstantFoldingPass.SymbolTable | None" = field(default=None)
        # 记录本作用域内声明的变量，用于区分"声明"与"赋值"
        # 避免循环内临时变量（如 calc_2）触发不必要的向上传播
        declared_vars: Set[str] = field(factory=set)

        def find(self, name: str) -> Reference | ConstantFoldingPass.FoldingFlags:
            """在当前作用域及其祖先作用域中查找符号"""
            if name in self.table:
                return self.table[name]

            if self.parent is not None:
                return self.parent.find(name)

            return ConstantFoldingPass.FoldingFlags.UNDEFINED

        def set(self, name: str, value: Reference | ConstantFoldingPass.FoldingFlags) -> None:
            """在当前作用域设置符号"""
            self.table[name] = value

        def copy_state(self) -> dict[str, Reference | ConstantFoldingPass.FoldingFlags]:
            """复制当前符号表状态（包括父级）"""
            state = {}
            # 从根到叶收集
            stack = []
            current = self
            while current:
                stack.append(current)
                current = current.parent
            # 反向应用（父级先，子级后）
            for scope in reversed(stack):
                state.update(scope.table)
            return state

    def __init__(self, builder: IRBuilder, config: CompileConfig):
        super().__init__(builder, config)
        self.changed = False
        self.global_table = self.SymbolTable("global", StructureType.GLOBAL)
        self.current_table: ConstantFoldingPass.SymbolTable = self.global_table

        # 控制流分析相关
        self.pending_branches: dict[str, list[dict]] = {}  # 等待处理的分支: {jump_target: [branch_states]}
        self.branch_base_state: dict[str, dict] = {}  # 分支开始前的状态

    def execute(self, context) -> bool:
        """执行常量折叠优化"""
        self.changed = False
        # 预扫描，识别条件分支结构
        self._prescan_branches()

        # 第二步：执行常量折叠
        self._perform_folding()

        return self.changed

    def _prescan_branches(self):
        """预扫描，识别所有条件分支及其父作用域"""
        self.conditional_branches: dict[str, str | None] = {}  # {branch_name: parent_scope}
        self.branch_groups = {}  # {parent_scope: [branch1, branch2]}

        scope_stack = []

        for instr in self.builder:
            if instr.opcode == IROpCode.SCOPE_BEGIN:
                scope_name = instr.get_operands()[0]
                scope_type = instr.get_operands()[1]

                if scope_type == StructureType.CONDITIONAL:
                    parent = scope_stack[-1] if scope_stack else "global"
                    self.conditional_branches[scope_name] = parent

                    if parent not in self.branch_groups:
                        self.branch_groups[parent] = []
                    self.branch_groups[parent].append(scope_name)

                scope_stack.append(scope_name)

            elif instr.opcode == IROpCode.SCOPE_END:
                if scope_stack:
                    scope_stack.pop()

    def _perform_folding(self):
        """执行常量折叠"""
        iterator = self.builder.__iter__()
        instruction_handlers = {
            IROpCode.SCOPE_BEGIN: self._handle_scope_begin,
            IROpCode.SCOPE_END: self._handle_scope_end,
            IROpCode.ASSIGN: self._assign,
            IROpCode.DECLARE: self._declare,
            IROpCode.BINARY_OP: self._op,
            IROpCode.COMPARE: self._compare,
            IROpCode.UNARY_OP: self._unary_op,
            IROpCode.COND_JUMP: self._cond_jump,
            IROpCode.CALL: self._call,
            IROpCode.CAST: self._cast,
            IROpCode.FUNCTION: self._function,
            IROpCode.RETURN: self._return,
            IROpCode.COMPUTE: self._compute
        }

        # 跟踪当前所在的作用域路径
        self.scope_path = []

        while True:
            try:
                instr = next(iterator)
                opcode = instr.opcode
            except StopIteration:
                break

            handler = instruction_handlers.get(opcode)
            if handler:
                if handler(iterator, instr):  # NOQA
                    self.changed = True

    def _find(self, name: Variable | Literal | Reference) -> Reference[Literal] | FoldingFlags:
        """从符号表搜索符号的最终值"""
        if isinstance(name, Literal):
            return Reference(name)
        if isinstance(name, Reference) and name.value_type == ValueType.LITERAL:
            return name

        # 在 loop_check 中查找任何变量都应视为 UNKNOWN
        current_scope = self.current_table
        while current_scope:
            if current_scope.stype == StructureType.LOOP_CHECK:
                return ConstantFoldingPass.FoldingFlags.UNKNOWN
            current_scope = current_scope.parent

        value = self.current_table.find(name.get_name())
        if value == ConstantFoldingPass.FoldingFlags.UNKNOWN:
            return value
        elif value == ConstantFoldingPass.FoldingFlags.UNDEFINED:
            return value
        elif value.value_type == ValueType.LITERAL:
            return value
        elif value.value_type == ValueType.FUNCTION:
            return value
        elif value.value_type == ValueType.VARIABLE:
            return self._find(value)
        else:
            return ConstantFoldingPass.FoldingFlags.UNKNOWN

    def _resolve_ref(
            self,
            ref: Reference
    ) -> Reference | FoldingFlags:
        """解析引用到字面量或标识为未知/未定义"""
        if ref.value_type == ValueType.LITERAL:
            return ref
        else:
            return self._find(ref)

    @staticmethod
    def _is_literal(ref: Reference[Literal] | FoldingFlags) -> bool:
        """判断是否为字面量"""
        return (
                not isinstance(ref, ConstantFoldingPass.FoldingFlags) and
                ref.value_type == ValueType.LITERAL
        )

    def _handle_scope_begin(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理作用域开始"""
        scope_name = instr.get_operands()[0]
        scope_type = instr.get_operands()[1]

        self.scope_path.append(scope_name)

        # 如果是条件分支
        if scope_type == StructureType.CONDITIONAL:
            parent_scope = self.conditional_branches.get(scope_name)

            # 检查是否在循环体中
            in_loop_body = False
            current = self.current_table
            while current:
                if current.stype == StructureType.LOOP_BODY:
                    in_loop_body = True
                    break
                current = current.parent

            # 如果在循环体中，不使用 branch_base_state 机制
            if in_loop_body:
                new_table = ConstantFoldingPass.SymbolTable(
                    scope_name,
                    scope_type,
                    parent=self.current_table
                )
                self.current_table = new_table
                return False

            # 第一次遇到这个父作用域的条件分支
            if parent_scope and parent_scope not in self.branch_base_state:
                # 保存当前符号表状态
                self.branch_base_state[parent_scope] = self.current_table.copy_state()

            # 从基础状态创建新的符号表
            if parent_scope and parent_scope in self.branch_base_state:
                base_state = self.branch_base_state[parent_scope]
                new_table = ConstantFoldingPass.SymbolTable(
                    scope_name,
                    scope_type,
                    parent=self.current_table
                )
                # 恢复基础状态到新表
                for var_name, value in base_state.items():
                    new_table.set(var_name, value)

                self.current_table = new_table
                return False

        # 普通作用域
        new_table = ConstantFoldingPass.SymbolTable(
            scope_name,
            scope_type,
            parent=self.current_table
        )
        self.current_table = new_table
        return False

    def _handle_scope_end(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理作用域结束"""
        scope_name = self.current_table.name
        scope_type = self.current_table.stype

        # 如果是条件分支结束，保存完整状态
        if scope_type == StructureType.CONDITIONAL:
            full_state = {}
            current = self.current_table
            while current:
                for var_name, value in current.table.items():
                    if var_name not in full_state:
                        full_state[var_name] = value
                current = current.parent

            if scope_name not in self.pending_branches:
                self.pending_branches[scope_name] = []
            self.pending_branches[scope_name].append(full_state)

        # 循环作用域结束时，向上传播变量遮蔽
        # 循环结束后父作用域中的旧值已不可信，必须标记为 UNKNOWN
        if scope_type in (StructureType.LOOP_BODY, StructureType.LOOP_CHECK):
            for var_name in self.current_table.table:
                # 只传播"赋值但未声明"的变量（即来自父作用域的变量）
                # 本作用域声明的临时变量（如 calc_2）不需要传播
                if var_name in self.current_table.declared_vars:
                    continue

                # 沿父链查找该变量的声明位置，标记为 UNKNOWN
                parent = self.current_table.parent
                while parent:
                    if var_name in parent.table:
                        parent.table[var_name] = ConstantFoldingPass.FoldingFlags.UNKNOWN
                        break
                    parent = parent.parent

        if self.current_table.parent is not None:
            self.current_table = self.current_table.parent

        if self.scope_path:
            self.scope_path.pop()

        return False

    def _declare(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理变量声明"""
        var: Variable = instr.get_operands()[0]
        self.current_table.set(var.get_name(), ConstantFoldingPass.FoldingFlags.UNKNOWN)
        # 记录本作用域声明的变量，用于区分"声明"与"赋值"
        self.current_table.declared_vars.add(var.get_name())
        return False

    def _assign(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理赋值指令"""
        target: Variable = instr.get_operands()[0]
        source_ref: Reference[Variable | Literal] = instr.get_operands()[1]

        resolved_source = source_ref
        changed = False

        if source_ref.value_type == ValueType.VARIABLE:
            new_source = self._resolve_ref(source_ref)
            if isinstance(new_source, ConstantFoldingPass.FoldingFlags):
                pass
            elif new_source.value_type == ValueType.LITERAL:
                new_instr = IRAssign(target, new_source)
                iterator.set_current(new_instr)
                resolved_source = new_source
                changed = True

        self.current_table.set(target.get_name(), resolved_source)
        return changed

    def _op(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理二元运算"""
        result: Variable = instr.get_operands()[0]
        op: BinaryOps = instr.get_operands()[1]
        left_ref: Reference[Variable | Literal] = instr.get_operands()[2]
        right_ref: Reference[Variable | Literal] = instr.get_operands()[3]

        self.current_table.set(result.get_name(), ConstantFoldingPass.FoldingFlags.UNKNOWN)

        left = self._resolve_ref(left_ref)
        right = self._resolve_ref(right_ref)

        # 两边任意一方非常量跳过
        if not self._is_literal(left) or not self._is_literal(right):
            return False

        left_dtype = left.get_dtype()
        right_dtype = right.get_dtype()

        # 两边有任意一方非基本类型跳过
        if not isinstance(left_dtype, PrimitiveDataType) or not isinstance(right_dtype, PrimitiveDataType):
            return False

        if op == BinaryOps.ADD and (left_dtype == PrimitiveDataType.STRING or right_dtype == PrimitiveDataType.STRING):
            new_value = str(left.value.value) + str(right.value.value)
        else:
            new_value = number_to_int32(int(BINARY_OP_HANDLERS[op](left.value.value, right.value.value)))

        try:
            # 用新指令替换原始指令
            new_instr = IRAssign(result, Reference.literal(new_value))
            iterator.set_current(new_instr)
            self._assign(iterator, new_instr)
            return True
        except (TypeError, ValueError, ZeroDivisionError):
            return False

    def _compare(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理比较运算"""
        result: Variable = instr.get_operands()[0]
        op: CompareOps = instr.get_operands()[1]
        left_ref: Reference[Variable | Literal] = instr.get_operands()[2]
        right_ref: Reference[Variable | Literal] = instr.get_operands()[3]

        self.current_table.set(result.get_name(), ConstantFoldingPass.FoldingFlags.UNKNOWN)

        left = self._resolve_ref(left_ref)
        right = self._resolve_ref(right_ref)

        # 两边任意一方非常量跳过
        if not self._is_literal(left) or not self._is_literal(right):
            return False

        left_dtype = left.get_dtype()
        right_dtype = right.get_dtype()

        # 两边有任意一方非基本类型跳过
        if not isinstance(left_dtype, PrimitiveDataType) or not isinstance(right_dtype, PrimitiveDataType):
            return False

        new_value = COMPARE_OP_HANDLERS[op](left.value.value, right.value.value)
        try:
            new_instr = IRAssign(result, Reference.literal(new_value))
            iterator.set_current(new_instr)
            self._assign(iterator, new_instr)
            return True
        except (TypeError, ValueError):
            return False

    def _unary_op(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理一元运算"""
        result: Variable = instr.get_operands()[0]
        op: UnaryOps = instr.get_operands()[1]
        operand_ref: Reference[Variable | Literal] = instr.get_operands()[2]

        self.current_table.set(result.get_name(), ConstantFoldingPass.FoldingFlags.UNKNOWN)

        operand = self._resolve_ref(operand_ref)
        if not self._is_literal(operand) or not isinstance(operand.get_dtype(), PrimitiveDataType):
            return False

        try:
            folded_value = number_to_int32(UNARY_OP_HANDLERS[op](operand.value.value))
            new_instr = IRAssign(result, Reference.literal(folded_value))
            iterator.set_current(new_instr)
            self._assign(iterator, new_instr)
            return True
        except (TypeError, ValueError):
            return False

    def _cond_jump(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """
        处理条件跳转

        关键：此时所有分支已经"执行"完毕，需要合并状态
        """
        cond: Reference[Variable | Literal] = instr.get_operands()[0]
        true_scope: str = instr.get_operands()[1]
        false_scope: str = instr.get_operands()[2]

        # 1. 先尝试优化条件本身
        changed = False

        if not cond.is_literal():
            value = self._find(cond)

            if not isinstance(value, ConstantFoldingPass.FoldingFlags):
                if cond.dtype in (PrimitiveDataType.INT, PrimitiveDataType.BOOLEAN):
                    if isinstance(value, Reference) and value.value_type == ValueType.LITERAL:
                        cond_val = bool(value.value.value)
                        jump_scope = true_scope if cond_val else false_scope

                        # 条件是常量，选择对应分支的状态
                        selected_state = self.pending_branches.get(jump_scope, [{}])[
                            0] if jump_scope in self.pending_branches else {}

                        # 将选中分支的状态应用到当前符号表
                        for var_name, val in selected_state.items():
                            self.current_table.set(var_name, val)

                        # 替换为直接跳转
                        if jump_scope:
                            iterator.set_current(IRJump(jump_scope))
                        else:
                            iterator.remove_current()

                        # 清理
                        self.pending_branches.pop(true_scope, None)
                        self.pending_branches.pop(false_scope, None)
                        self.branch_base_state.pop(self.conditional_branches.get(true_scope), None)
                        self.branch_base_state.pop(self.conditional_branches.get(false_scope), None)

                        return True
        else:  # 是字面量
            cond_val = bool(cond.value.value)
            jump_scope = true_scope if cond_val else false_scope

            # 条件是字面量，选择对应分支的状态
            selected_state = self.pending_branches.get(jump_scope, [{}])[
                0] if jump_scope in self.pending_branches else {}

            # 将选中分支的状态应用到当前符号表
            for var_name, val in selected_state.items():
                self.current_table.set(var_name, val)

            # 替换为直接跳转
            if jump_scope:
                iterator.set_current(IRJump(jump_scope))
            else:
                iterator.remove_current()

            # 清理
            self.pending_branches.pop(true_scope, None)
            self.pending_branches.pop(false_scope, None)
            self.branch_base_state.pop(self.conditional_branches.get(true_scope), None)
            self.branch_base_state.pop(self.conditional_branches.get(false_scope), None)

            return True

        # 2. 条件不确定，合并两个分支的完整状态
        true_state = self.pending_branches.get(true_scope, [{}])[0] if true_scope in self.pending_branches else {}
        false_state = self.pending_branches.get(false_scope, [{}])[0] if false_scope in self.pending_branches else {}

        # 修复：获取分支前的基准状态，作为 false 分支无显式作用域时的默认值
        # 避免 false_state 为空导致未修改变量被误判为 UNKNOWN
        parent_scope = self.conditional_branches.get(true_scope)
        base_state = self.branch_base_state.get(parent_scope, {}) if parent_scope else {}

        # 找出所有变量（两个完整状态的并集 + 基准状态）
        all_vars = set(true_state.keys()) | set(false_state.keys()) | set(base_state.keys())

        for var_name in all_vars:
            true_val = true_state.get(var_name, base_state.get(var_name, self.FoldingFlags.UNKNOWN))
            false_val = false_state.get(var_name, base_state.get(var_name, self.FoldingFlags.UNKNOWN))

            # 如果两个分支的值相同，使用该值
            if self._values_equal(true_val, false_val):
                self.current_table.set(var_name, true_val)
            else:
                # 值不同，标记为 UNKNOWN
                self.current_table.set(var_name, self.FoldingFlags.UNKNOWN)

        # 清理已处理的分支
        self.pending_branches.pop(true_scope, None)
        self.pending_branches.pop(false_scope, None)

        # 清理基础状态（从 conditional_branches 中查找父作用域）
        if parent_scope:
            self.branch_base_state.pop(parent_scope, None)

        return changed

    def _values_equal(self, v1: Any, v2: Any) -> bool:
        """比较两个值是否相等"""
        if isinstance(v1, self.FoldingFlags) or isinstance(v2, self.FoldingFlags):
            return v1 == v2

        if not isinstance(v1, Reference) or not isinstance(v2, Reference):
            return False

        if v1.value_type != v2.value_type:
            return False

        if v1.value_type == ValueType.LITERAL:
            return v1.value.value == v2.value.value

        if v1.value_type == ValueType.VARIABLE:
            return v1.get_name() == v2.get_name()

        return False

    def _call(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理函数调用，优化参数"""
        result: Variable = instr.get_operands()[0]
        func: Function = instr.get_operands()[1]
        args: dict[str, Reference[Variable | Literal]] = instr.get_operands()[2]

        new_args: dict[str, Reference[Variable | Literal]] = {}
        changed = False

        for param_name, arg_ref in args.items():
            if arg_ref.value_type == ValueType.LITERAL:
                new_args[param_name] = arg_ref
                continue

            if arg_ref.value_type == ValueType.VARIABLE:
                arg_value = self._find(arg_ref.value)
                if isinstance(arg_value, ConstantFoldingPass.FoldingFlags):
                    new_args[param_name] = arg_ref
                else:
                    new_args[param_name] = arg_value
                    changed = True
            else:
                new_args[param_name] = arg_ref

        if changed:
            iterator.set_current(IRCall(result, func, new_args))

        return changed

    def _cast(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理类型转换"""
        result: Variable = instr.get_operands()[0]
        dtype: PrimitiveDataType | Class = instr.get_operands()[1]
        value_ref: Reference[Variable | Literal] = instr.get_operands()[2]

        self.current_table.set(result.get_name(), ConstantFoldingPass.FoldingFlags.UNKNOWN)

        value = self._resolve_ref(value_ref)
        if isinstance(value, ConstantFoldingPass.FoldingFlags):
            return False

        if isinstance(value, Reference) and value.value_type == ValueType.LITERAL:
            if dtype == value.get_dtype():
                new_assign = IRAssign(result, value)
                iterator.set_current(new_assign)
                self._assign(iterator, new_assign)
                return True

            if dtype == PrimitiveDataType.STRING and value.get_dtype() in (PrimitiveDataType.INT,
                                                                           PrimitiveDataType.BOOLEAN):
                str_val = str(int(value.value.value))
                str_literal_ref = Reference.literal(str_val)
                new_assign = IRAssign(result, str_literal_ref)
                iterator.set_current(new_assign)
                self._assign(iterator, new_assign)
                return True

        return False

    def _function(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理函数定义"""
        function: Function = instr.get_operands()[0]
        self.current_table.set(function.get_name(), Reference(function))
        return False

    def _return(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """处理返回指令"""
        value_ref = instr.get_operands()[0]
        if not isinstance(value_ref, Reference) or value_ref.value_type != ValueType.VARIABLE:
            return False

        # 防御性检查：如果当前仍在循环作用域内，不折叠返回值
        # （正常情况下 _find 的 LOOP_CHECK 保护已拦截，此处为额外安全网）
        current = self.current_table
        while current:
            if current.stype in (StructureType.LOOP_BODY, StructureType.LOOP_CHECK):
                return False
            current = current.parent

        resolved = self._resolve_ref(value_ref)
        if not self._is_literal(resolved):
            return False

        resolved: Reference[Literal]

        # 用字面量替换 return 的操作数
        new_instr = IRReturn(resolved)
        iterator.set_current(new_instr)
        return True

    def _compute(self, iterator: IRBuilderIterator, instr: IRInstruction) -> bool:
        """
        处理 COMPUTE 指令的常量折叠。

        两种优化：
          1. 全常量求值：provider_tree 所有叶节点都是字面量 → 编译时计算
          2. 部分传播：provider_tree 中的变量叶节点如果已知为常量 → 替换为字面量
        """
        result: Variable = instr.get_operands()[0]
        tree: dict = instr.get_operands()[1]
        compute_kind: str = instr.get_operands()[2]
        scale: float | None = instr.get_operands()[3]

        self.current_table.set(result.get_name(), ConstantFoldingPass.FoldingFlags.UNKNOWN)

        # 先尝试部分传播：把已知常量的变量叶替换为字面量
        new_tree, propagated = self._propagate_tree(tree)

        # 再尝试全常量求值
        value = self._try_eval_tree(new_tree)
        if value is not None:
            try:
                if compute_kind == "integer":
                    folded = number_to_int32(int(value))
                else:
                    folded = float(value)
                    if scale is not None:
                        folded *= scale
                new_instr = IRAssign(result, Reference.literal(folded))
                iterator.set_current(new_instr)
                self._assign(iterator, new_instr)
                return True
            except (TypeError, ValueError):
                pass

        # 没全折叠，但做了传播 → 更新指令
        if propagated:
            iterator.set_current(IRCompute(result, new_tree, compute_kind, scale))
            return True

        return False

    def _propagate_tree(self, node) -> tuple[Any, bool]:
        """
        递归传播 provider_tree 中已知为常量的变量叶节点。

        26.3 格式：
          multi:  {"type": "minecraft:add", "inputs": [...]}
          binary: {"type": "minecraft:sub", "left": ..., "right": ...}
          unary:  {"type": "minecraft:abs", "input": ...}
        """
        if isinstance(node, (int, float)):
            return node, False

        if isinstance(node, Reference):
            if node.value_type == ValueType.LITERAL:
                return node, False
            value = self._resolve_ref(node)
            if self._is_literal(value):
                return value, True
            return node, False

        if isinstance(node, dict):
            changed = False
            type_str = node.get("type", "")

            # multi-arg: "inputs" 列表
            if "inputs" in node:
                new_inputs = []
                for child in node["inputs"]:
                    new_child, c = self._propagate_tree(child)
                    new_inputs.append(new_child)
                    changed = changed or c
                if changed:
                    return {"type": type_str, "inputs": new_inputs}, True
                return node, False

            # binary: "left" / "right"（或自定义键如 "base"/"exponent"）
            new_dict = {"type": type_str}
            for key in ("left", "right", "base", "exponent"):
                if key in node:
                    new_val, c = self._propagate_tree(node[key])
                    new_dict[key] = new_val
                    changed = changed or c

            # unary: "input"
            if "input" in node:
                new_val, c = self._propagate_tree(node["input"])
                new_dict["input"] = new_val
                changed = changed or c

            # 拷贝其他未知键（防御性）
            for k, v in node.items():
                if k not in new_dict:
                    new_dict[k] = v

            if changed:
                return new_dict, True
            return node, False

        return node, False

    def _try_eval_tree(self, node) -> Optional[int | float]:
        """
        尝试对整棵 provider_tree 求值。
        所有叶节点必须是字面量，否则返回 None。
        """
        if isinstance(node, (int, float)):
            return node

        if isinstance(node, Reference):
            if node.value_type == ValueType.LITERAL:
                try:
                    return node.value.value
                except AttributeError:
                    return None
            return None

        if isinstance(node, dict):
            type_str = node.get("type", "")
            # 去掉 minecraft: 前缀
            mc_type = type_str.replace("minecraft:", "") if type_str.startswith("minecraft:") else type_str

            # multi-arg: "inputs" 列表
            if "inputs" in node:
                handler = _MULTI_ARG_EVAL.get(mc_type)
                if handler is None:
                    return None
                evaluated = []
                for child in node["inputs"]:
                    v = self._try_eval_tree(child)
                    if v is None:
                        return None
                    evaluated.append(v)
                try:
                    return handler(evaluated)
                except (ZeroDivisionError, ValueError, TypeError):
                    return None

            # binary: "left" / "right"（或 "base" / "exponent"）
            left_key = None
            right_key = None
            for lk, rk in (("left", "right"), ("base", "exponent")):
                if lk in node and rk in node:
                    left_key, right_key = lk, rk
                    break
            if left_key is not None:
                handler = _BINARY_EVAL.get(mc_type)
                if handler is None:
                    return None
                lv = self._try_eval_tree(node[left_key])
                rv = self._try_eval_tree(node[right_key])
                if lv is None or rv is None:
                    return None
                try:
                    result = handler(lv, rv)
                    return result
                except (ZeroDivisionError, ValueError, TypeError):
                    return None

            # unary: "input"
            if "input" in node:
                handler = _UNARY_EVAL.get(mc_type)
                if handler is None:
                    return None
                v = self._try_eval_tree(node["input"])
                if v is None:
                    return None
                try:
                    return handler(v)
                except (ZeroDivisionError, ValueError, TypeError):
                    return None

            return None

        return None
