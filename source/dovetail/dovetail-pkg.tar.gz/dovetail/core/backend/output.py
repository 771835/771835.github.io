# coding=utf-8
"""
输出管理系统
"""
import shutil
import zipfile
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Dict, Callable, Optional

from dovetail.core.backend.context import GenerationContext, Scope, DependencyFile
from dovetail.core.config import PROJECT_NAME, PROJECT_WEBSITE, PROJECT_VERSION
from dovetail.utils.datapack_format import get_datapack_format
from dovetail.utils.download_tool import download_dependencies
from dovetail.utils.logger import get_logger

logger = get_logger(__name__)


class OutputWriter(ABC):
    """输出写入器基类"""

    @abstractmethod
    def write(self, context: GenerationContext):
        """
        写入输出

        Args:
            context: 生成上下文
        """
        raise NotImplementedError()

    @abstractmethod
    def get_name(self) -> str:
        """
        返回写入器名称

        Returns:
            str: 写入器名称
        """
        raise NotImplementedError()


class CommandWriter(OutputWriter):
    """命令文件写入器"""

    def write(self, context: GenerationContext):
        """写入所有mcfunction文件"""
        command_cnt = 0
        for scope in context.get_all_scopes():
            if scope.has_commands():
                command_cnt += self._write_scope(scope, context)
        logger.info(f"共写入 {command_cnt} 条指令")

    def _write_scope(self, scope: Scope, context: GenerationContext) -> int:
        """写入单个作用域的命令文件"""
        file_path = context.target / context.namespace / "data" / context.namespace / "function" / scope.get_file_path()
        file_path.parent.mkdir(parents=True, exist_ok=True)

        with open(file_path, 'w', encoding='utf-8') as f:
            if context.config.debug:
                f.write(f"# Scope: {scope.name} ({scope.scope_type.value})\n")
                f.write(f"# Commands: {len(scope.commands)}\n")
                f.write(f"# Time: {datetime.now()}\n")
                f.write(f"# Maker: {PROJECT_NAME} {PROJECT_VERSION}({PROJECT_WEBSITE})\n")
                f.write(f"# Minecraft Version: {context.config.version}\n\n")

            f.write('\n'.join(scope.commands))
        return len(scope.commands)

    def get_name(self) -> str:
        return "command_writer"


class FunctionWriter(OutputWriter):
    """内置函数写入器"""

    def __init__(
            self,
            builtin_functions: Optional[dict[str, str]] = None,
            callback: Optional[Callable[[], dict[str, str]]] = None
    ):
        """
        Args:
            builtin_functions: 内置函数映射 {函数路径: 函数内容}
            callback: 回调函数，返回内置函数映射表，当 builtin_functions 存在时更新 builtin_functions
        """
        self.builtin_functions = builtin_functions or {}
        self.callback = callback

    def write(self, context: GenerationContext):
        """写入内置函数"""
        if self.callback and callable(self.callback):
            self.builtin_functions.update(self.callback())

        function_dir: Path = context.target / context.namespace / "data" / context.namespace / "function"
        function_dir.mkdir(parents=True, exist_ok=True)

        for func_name, func_content in self.builtin_functions.items():
            func_path = function_dir / f"{func_name}.mcfunction"
            func_path.parent.mkdir(parents=True, exist_ok=True)
            with open(func_path, 'w', encoding='utf-8') as f:
                f.write(func_content)

    def get_name(self) -> str:
        return "function_writer"


class MetadataWriter(OutputWriter):
    """元数据写入器"""

    def write(self, context: GenerationContext):
        """写入 pack.mcmeta 基本结构"""
        pack_format = get_datapack_format(context.config.version)
        context.pack_meta.description = context.config.description or context.namespace
        context.pack_meta.min_format = pack_format
        context.pack_meta.max_format = pack_format
        # 写入文件
        context.pack_meta.save_file(context.config.version)

    def get_name(self) -> str:
        return "metadata_writer"


class DependentDatapackWriter(OutputWriter):
    """依赖数据包写入器"""

    def __init__(self, dependency_files: Optional[list[DependencyFile]] = None):
        """
        Args:
            dependency_files: 依赖数据包
        """
        self.dependency_files: list[DependencyFile] = dependency_files or []

    def write(self, context: GenerationContext):
        """下载和写入依赖文件"""
        for dependency_file in self.dependency_files:
            url = dependency_file.url
            sha256 = dependency_file.sha256

            pack_path = download_dependencies(url, sha256)
            name = sha256[:12] if sha256 else str(hash(url))
            dst = context.target / context.namespace / name

            if pack_path is None:
                logger.error(f"Download dependence failed for {url}")
                continue

            context.pack_meta.add_overlay(
                name,
                (
                    dependency_file.min_version,
                    dependency_file.max_version
                )
            )

            if pack_path.is_file():
                if zipfile.is_zipfile(pack_path):
                    self._extract_zipfile(pack_path, dst)
                else:
                    logger.warning(f"Unknown dependency file: {pack_path}")
            elif pack_path.is_dir():
                shutil.copy(pack_path, dst)

            # 执行 hook 事务
            if dependency_file.hook and callable(dependency_file.hook):
                dependency_file.hook(dst, context.config.version)

        context.pack_meta.save_file(context.config.version)

    @staticmethod
    def _extract_zipfile(zip_path: Path, extract_to: Path) -> bool:
        with zipfile.ZipFile(zip_path) as zip_ref:
            namelist = zip_ref.namelist()

            # 定位根目录
            pack_root = ''
            if 'pack.mcmeta' not in namelist:
                for name in namelist:
                    if '/' in name and name.count('/') == 1 and name.endswith('pack.mcmeta'):
                        pack_root = name.rsplit('/', 1)[0] + '/'
                        break
                else:
                    return False

            prefix_len = len(pack_root)

            # 收集文件信息
            files_to_extract = []
            dirs_needed = set()

            for member in zip_ref.infolist():
                if member.is_dir() or not member.filename.startswith(pack_root):
                    continue

                relative_path = member.filename[prefix_len:]
                if not relative_path:
                    continue

                target_path = extract_to / relative_path
                files_to_extract.append((member, target_path, member.file_size))
                dirs_needed.add(target_path.parent)

            # 批量创建目录
            extract_to.mkdir(parents=True, exist_ok=True)
            for d in sorted(dirs_needed, key=lambda p: len(p.parts)):
                d.mkdir(parents=True, exist_ok=True)

            # 按大小排序：先处理小文件（利用缓存局部性）
            files_to_extract.sort(key=lambda x: x[2])

            # 批量读取小文件（< 1MB）
            small_threshold = 1048576
            small_data = {}

            for member, target, size in files_to_extract:
                if size < small_threshold:
                    small_data[target] = zip_ref.read(member)
                else:
                    break  # 已排序，后面都是大文件

            # 批量写入小文件
            for target, data in small_data.items():
                target.write_bytes(data)

            # 流式处理大文件
            for member, target, size in files_to_extract:
                if size >= small_threshold:
                    buffer_size = min(2097152, max(262144, size // 10))  # 自适应 buffer
                    with zip_ref.open(member) as src:
                        with open(target, 'wb', buffering=buffer_size) as dst:
                            shutil.copyfileobj(src, dst, length=buffer_size)

            return True

    def get_name(self) -> str:
        return "dependent_datapack_writer"


class TagWriter(OutputWriter):
    """标签写入器（用于minecraft:load和minecraft:tick）"""

    def __init__(self, load_functions: Optional[list[str]] = None, tick_functions: Optional[list[str]] = None):
        """
        Args:
            load_functions: 需要在load时执行的函数列表
            tick_functions: 需要在tick时执行的函数列表
        """
        self.load_functions = load_functions or []
        self.tick_functions = tick_functions or []

    def write(self, context: GenerationContext):
        """写入标签文件"""
        tags_dir = context.target / context.namespace / "data" / "minecraft" / "tags" / "function"
        tags_dir.mkdir(parents=True, exist_ok=True)

        # 写入load标签
        if self.load_functions:
            self._write_tag(tags_dir / "load.json", self.load_functions, context)

        # 写入tick标签
        if self.tick_functions:
            self._write_tag(tags_dir / "tick.json", self.tick_functions, context)

    def _write_tag(self, path: Path, functions: list[str], context: GenerationContext):
        """写入单个标签文件"""
        import json

        # 添加命名空间前缀
        values = [f"{context.namespace}:{func}" for func in functions]

        tag_content = {
            "values": values
        }

        with open(path, 'w', encoding='utf-8') as f:
            json.dump(tag_content, f, indent=2)

    def get_name(self) -> str:
        return "tag_writer"


class OutputManager:
    """输出管理器，协调所有写入器"""

    def __init__(self):
        self.writers: Dict[str, OutputWriter] = {}

    def register_writer(self, writer: OutputWriter):
        """注册写入器"""
        self.writers[writer.get_name()] = writer

    def unregister_writer(self, name: str):
        """移除写入器"""
        if name in self.writers:
            del self.writers[name]

    def write_all(self, context: GenerationContext):
        """执行所有写入器"""
        for name, writer in self.writers.items():
            try:
                writer.write(context)
            except Exception as e:
                logger.error(f"Writer {name}: {e}")
                if context.config.debug:
                    raise

    def get_writer(self, name: str) -> OutputWriter | None:
        """获取指定写入器"""
        return self.writers.get(name)
