# coding=utf-8
# 此文件由构建脚本自动生成，请勿手动修改
PROJECT_VERSION = "dev20260827"
COMMIT_HASH = "46dc9e3e"
