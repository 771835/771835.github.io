# coding=utf-8
from .template import CommandTemplate, TemplateRegistry


def register_builtin_templates():
    """注册所有内置模板"""

    templates = [
        # ============ 基础命令 ============
        CommandTemplate(
            name="exec",
            template="$(command)",
            function_path="builtins/exec",
            param_names=["command"],
            description="执行原始 Minecraft 命令",
            tags=["basic", "core"]
        ),

        CommandTemplate(
            name="strcat_fast",
            template="data modify storage $(target) $(path) set value '$(a)$(b)'",
            function_path="builtins/strcat_fast",
            param_names=["target", "path", "a", "b"],
            description="快速字符串拼接(不支持特殊字符的拼接，面对特殊字符容易出现未知的错误)",
            tags=["data", "string", "fast", "storage"]
        ),

        # ============ Tellraw 系列 ============
        CommandTemplate(
            name="tellraw_nbt",
            template='tellraw $(target) {"storage":"$(objective)","nbt":"$(path)"}',
            function_path="builtins/tellraw/tellraw_nbt",
            param_names=["target", "objective", "path"],
            description="向指定目标发送指定nbt路径中的文本消息",
            tags=["ui", "tellraw"]
        ),

        CommandTemplate(
            name="tellraw",
            template="tellraw $(target) $(json)",
            function_path="builtins/tellraw/tellraw",
            param_names=["target", "json"],
            description="向指定目标发送文本组件(1.21.5及以上)/json(1.21.5以下)",
            tags=["ui", "tellraw"]
        ),

        # ============ Random 系列 ============
        CommandTemplate(
            name="randint",
            template="execute store result score output_randint $(objective) run random value $(min)..$(max)",
            function_path="builtins/random/randint",
            param_names=["objective", "min", "max"],
            description="生成随机数到指定位置",
            tags=["random", "math"]
        ),

        CommandTemplate(
            name="randint_fast",
            template="execute store result score $(path) $(objective) run random value $(min)..$(max)",
            function_path="builtins/random/randint",
            param_names=["objective", "path", "min", "max"],
            description="生成随机数到指定位置(较randint少一条指令)",
            tags=["random", "math"]
        ),

        # ============ Setblock 系列 ============
        CommandTemplate(
            name="setblock",
            template="setblock $(x) $(y) $(z) $(block) $(mode)",
            function_path="builtins/setblock/setblock_a",
            param_names=["x", "y", "z", "block"],
            optional_params={"mode": "replace"},
            description="放置方块",
            tags=["world", "block"]
        ),

        CommandTemplate(
            name="setblock_destroy",
            template="setblock $(x) $(y) $(z) $(block) destroy",
            function_path="builtins/setblock/setblock_d",
            param_names=["x", "y", "z", "block"],
            description="破坏性放置方块",
            tags=["world", "block"]
        ),

        # # ============ List 操作 ============
        # CommandTemplate(
        #     name="list_setitem",
        #     template="data modify storage $(target) object.$(id).value[$(index)] set value $(value)",
        #     function_path="builtins/data/list_setitem_value",
        #     param_names=["target", "id", "index", "value"],
        #     description="设置列表元素",
        #     tags=["data", "list"]
        # ),
        #
        # CommandTemplate(
        #     name="list_getitem",
        #     template="data modify storage $(target) $(target_path) set from storage $(source) object.$(id).value[$(index)]",
        #     function_path="builtins/data/list_getitem_storage",
        #     param_names=["target", "target_path", "source", "id", "index"],
        #     description="获取列表元素",
        #     tags=["data", "list"]
        # ),

        # ============ OOP 系列 ============
        CommandTemplate(
            name="oop_get_property_score",
            template="execute store result score $(target) $(objective) run data get storage $(source) object.$(id).$(property) 1",
            function_path="builtins/oop/get_property_score",
            param_names=["target", "objective", "source", "id", "property"],
            description="获取对象属性到记分板",
            tags=["oop", "property"]
        ),

        CommandTemplate(
            name="oop_set_property_value",
            template='data modify storage $(target) object.$(id).$(property) set value "$(value)"',
            function_path="builtins/oop/set_property_storage_value",
            param_names=["target", "id", "property", "value"],
            description="设置对象属性值",
            tags=["oop", "property"]
        ),

        # ============ 实体操作 ============
        CommandTemplate(
            name="tp",
            template="tp $(target) $(x) $(y) $(z) $(rotation)",
            function_path="builtins/tp",
            param_names=["target", "x", "y", "z"],
            optional_params={"rotation": ""},
            description="传送实体",
            tags=["entity", "world"]
        ),

        CommandTemplate(
            name="summon",
            template="summon $(entity_type) $(x) $(y) $(z) $(nbt)",
            function_path="builtins/summon",
            param_names=["entity_type", "x", "y", "z"],
            optional_params={"nbt": "{}"},
            description="生成实体",
            tags=["entity", "world"]
        ),

        CommandTemplate(
            name="kill",
            template="kill $(target)",
            function_path="builtins/kill",
            param_names=["target"],
            description="杀死实体",
            tags=["entity"]
        ),

        # ============ 世界操作 ============
        CommandTemplate(
            name="time_set",
            template="time set $(value)",
            function_path="builtins/time_set",
            param_names=["value"],
            description="设置世界时间",
            tags=["world", "time"]
        ),

        CommandTemplate(
            name="weather",
            template="weather $(type) $(duration)",
            function_path="builtins/weather",
            param_names=["type"],
            optional_params={"duration": ""},
            description="设置天气",
            tags=["world", "weather"]
        ),

        # ============ String 操作 ============

        CommandTemplate(
            name="substring",
            template="data modify storage $(target) $(path) set string storage $(source) $(source_path) $(start) $(end)",
            function_path="builtins/string/substring",
            param_names=["target", "source", "path", "source_path"],
            optional_params={"start": "", "end": ""},
            description="截取字符串切片",
            tags=["string", "data"]
        ),

        CommandTemplate(
            name="to_integer",
            template=f"scoreboard players set $(path) $(objective) $(value)",
            function_path=f"builtins/int/to_integer",
            param_names=["objective", "path", "value"],
            description="转换字符串为数字",
            tags=["int", "data"]
        ),

        # ============ Array 操作 ============

        CommandTemplate(
            name="array_access_to_score",
            template="execute store result score $(path) $(objective) run data get storage $(source) $(source_path)[$(index)]",
            function_path="builtins/array_access_to_score",
            param_names=["path", "objective", "index", "source", "source_path"],
            description="访问数组路径并写入记分板",
            tags=["data", "array", "score"]
        ),

        CommandTemplate(
            name="array_access_to_storage",
            template="data modify storage $(target) $(target_path) set from storage $(source) $(source_path)[$(index)]",
            function_path="builtins/array_access_to_storage",
            param_names=["target", "target_path", "index", "source", "source_path"],
            description="访问数组路径并写入存储",
            tags=["data", "array", "storage"]
        ),

        CommandTemplate(
            name="array_assign",
            template="data modify storage $(target) $(path)[$(index)] set value $(value)",
            function_path="builtins/array_assign",
            param_names=["target", "path", "index", "value"],
            description="给数组赋值",
            tags=["data", "array"]
        ),

        # ============ Data 读取操作 ============
        CommandTemplate(
            name="data_get_block",
            template="data modify storage $(target) $(target_path) set string block $(x) $(y) $(z) $(path)",
            function_path="builtins/data/get_block",
            param_names=["target", "target_path", "x", "y", "z"],
            optional_params={"path": ""},
            description="从方块中读取数据并转换为字符串",
            tags=["data", "getting", "block"]
        ),

        CommandTemplate(
            name="data_get_entity",
            template="data modify storage $(target) $(target_path) set string entity $(source) $(path)",
            function_path="builtins/data/get_entity",
            param_names=["target", "target_path", "source"],
            optional_params={"path": ""},
            description="从实体中读取数据并转换为字符串",
            tags=["data", "getting", "entity"]
        ),

        CommandTemplate(
            name="data_get_storage",
            template="data modify storage $(target) $(target_path) set string storage $(source) $(path)",
            function_path="builtins/data/get_storage",
            param_names=["target", "target_path", "source"],
            optional_params={"path": ""},
            description="从存储中读取数据并转换为字符串",
            tags=["data", "getting", "storage"]
        ),

        CommandTemplate(
            name="data_get_block_int",
            template="execute store result score $(target) $(objective) run data get block $(x) $(y) $(z) $(path) $(scale)",
            function_path="builtins/data/get_block_int",
            param_names=["target", "objective", "x", "y", "z"],
            optional_params={"path": "", "scale": 1},
            description="从方块中读取数据并转换为整数类型",
            tags=["data", "getting", "block"]
        ),

        CommandTemplate(
            name="data_get_entity_int",
            template="execute store result score $(target) $(objective) run data get entity $(source) $(path) $(scale)",
            function_path="builtins/data/get_entity_int",
            param_names=["target", "objective", "source"],
            optional_params={"path": "", "scale": 1},
            description="从实体中读取数据并转换为整数类型",
            tags=["data", "getting", "entity"]
        ),

        CommandTemplate(
            name="data_get_storage_int",
            template="execute store result score $(target) $(objective) run data get storage $(source) $(path) $(scale)",
            function_path="builtins/data/get_storage_int",
            param_names=["target", "objective", "source"],
            optional_params={"path": "", "scale": 1},
            description="从存储中读取数据并转换为整数类型",
            tags=["data", "getting", "storage"]
        ),

    ]

    # 批量注册
    for template in templates:
        TemplateRegistry.register(template)
