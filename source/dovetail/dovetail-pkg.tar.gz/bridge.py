# coding=utf-8
"""
Dovetail 在线编译桥接模块（Pyodide 环境）

所有浏览器兼容性补丁在此文件内完成。
外部 JS 只需: from bridge import compile_online, pack_output_zip

补丁清单:
  §1 修正 sys.argv[0] 让 resolve_project_path 指向虚拟文件系统根
  §2 注入假 requests 模块，底层用 pyodide.http.pyfetch 实现真实 HTTP
  §3 Monkey-patch resolve_project_path 强制项目根
  §4 确保 Lark 缓存目录存在
  §5 禁用线程化日志
  §6 核心编译桥接函数 compile_online / pack_output_zip
"""
import sys
import os
import types
import io
import json
import hashlib
import traceback
import shutil
import base64
import zipfile
from pathlib import Path
from contextlib import redirect_stdout, redirect_stderr
from typing import Optional

# ============================================================
# §1 环境基础设定 —— 必须在 import dovetail 之前
# ============================================================

_PROJECT_ROOT = Path("/dovetail-project")

# 1.1 修正 sys.argv[0]
sys.argv = [str(_PROJECT_ROOT / "main.py")]

# 1.2 确保项目根在 sys.path 上
_project_root_str = str(_PROJECT_ROOT)
if _project_root_str not in sys.path:
    sys.path.insert(0, _project_root_str)

# 1.3 创建工作目录
_workspace = Path("/workspace")
_workspace.mkdir(parents=True, exist_ok=True)
(_workspace / "target").mkdir(parents=True, exist_ok=True)


# ============================================================
# §2 注入假 requests —— 用 pyodide.http.pyfetch 模拟
# ============================================================

def _install_fake_requests():
    """
    构造与 requests 公开 API 兼容的假模块。

    覆盖 download_tool.py 中用到的:
      - requests.get(url, stream=, headers=, timeout=, verify=, proxies=)
      - requests.head(url, headers=, timeout=, proxies=, verify=)
      - requests.exceptions.Timeout
      - requests.exceptions.ConnectionError
      - requests.exceptions.HTTPError
      - requests.exceptions.RequestException
    """
    fake_requests = types.ModuleType("requests")
    fake_requests.__version__ = "0.0.0-fake-pyodide"
    fake_requests.__path__ = []  # 标记为 package 以便子模块导入

    # --- exceptions 子模块 ---
    exc_mod = types.ModuleType("requests.exceptions")
    exc_mod.__package__ = "requests.exceptions"

    class RequestException(Exception):
        """所有 requests 异常的基类"""
        pass

    class ConnectionError(RequestException):
        """网络连接错误"""
        pass

    class Timeout(RequestException):
        """请求超时"""
        pass

    class HTTPError(RequestException):
        """HTTP 错误响应 (4xx / 5xx)"""

        def __init__(self, message="", response=None):
            super().__init__(message)
            self.response = response

    class URLRequired(RequestException):
        """缺少 URL"""
        pass

    exc_mod.RequestException = RequestException
    exc_mod.ConnectionError = ConnectionError
    exc_mod.Timeout = Timeout
    exc_mod.HTTPError = HTTPError
    exc_mod.URLRequired = URLRequired

    # 挂到 requests 顶层
    fake_requests.exceptions = exc_mod
    fake_requests.RequestException = RequestException
    fake_requests.ConnectionError = ConnectionError
    fake_requests.Timeout = Timeout
    fake_requests.HTTPError = HTTPError
    fake_requests.URLRequired = URLRequired

    # --- Response 对象 ---
    class _FakeResponse:
        """
        模拟 requests.Response。
        底层持有 pyodide.http.FetchResponse。
        """

        def __init__(self, pyodide_response, url):
            self._resp = pyodide_response
            self.url = url
            self.status_code = pyodide_response.status
            self.headers = _CaseInsensitiveDict(dict(pyodide_response.headers))
            self._content = None
            self.encoding = "utf-8"
            self.reason = ""

        def raise_for_status(self):
            if 400 <= self.status_code < 600:
                raise HTTPError(
                    f"{self.status_code} Server Error: {self.url}",
                    response=self
                )

        @property
        def content(self):
            if self._content is None:
                self._content = self._resp.to_bytes()
            return self._content

        @property
        def text(self):
            return self.content.decode(self.encoding, errors="replace")

        def json(self, **kwargs):
            return json.loads(self.text)

        def iter_content(self, chunk_size=65536):
            """分块迭代，用于 stream=True 场景"""
            data = self.content
            for i in range(0, len(data), chunk_size):
                yield data[i:i + chunk_size]

        def close(self):
            pass

        def __repr__(self):
            return f"<Response [{self.status_code}]>"

    class _CaseInsensitiveDict(dict):
        """大小写不敏感的 header dict（requests 的默认行为）"""

        def __getitem__(self, key):
            return super().__getitem__(key.lower())

        def __setitem__(self, key, value):
            super().__setitem__(key.lower(), value)

        def __contains__(self, key):
            return super().__contains__(key.lower())

        def get(self, key, default=None):
            return super().get(key.lower(), default)

    # --- pyfetch 封装 ---
    async def _do_fetch(method, url, **kwargs):
        """
        用 pyodide.http.pyfetch 发请求。
        CORS 限制下只有同源或 CORS 友好的 URL 可用。
        """
        try:
            from pyodide.http import pyfetch
        except ImportError:
            raise ConnectionError("pyodide.http.pyfetch not available in this environment")

        headers = kwargs.get("headers") or {}
        timeout_val = kwargs.get("timeout", (10, 60))
        if isinstance(timeout_val, (list, tuple)):
            timeout_sec = timeout_val[0]
        else:
            timeout_sec = timeout_val

        try:
            # pyfetch 是协程，需用 await
            resp = await pyfetch(url, method=method, headers=headers, timeout=timeout_sec)
            return _FakeResponse(resp, url)

        except ConnectionError:
            raise
        except TimeoutError as e:
            raise Timeout(f"Request timed out: {e}")
        except OSError as e:
            raise ConnectionError(f"Connection error: {e}")
        except Exception as e:
            err_str = str(e)
            # 尝试从异常消息中提取 HTTP 状态码
            status = 500
            for code in range(400, 600):
                if str(code) in err_str:
                    status = code
                    break
            fake_resp = types.SimpleNamespace(
                status=status,
                headers={},
                to_bytes=lambda: b""
            )
            raise HTTPError(err_str, response=_FakeResponse(fake_resp, url))

    # --- 公开 API ---
    def get(url, params=None, **kwargs):
        """GET 请求"""
        if params:
            qs = "&".join(f"{k}={v}" for k, v in params.items())
            url = f"{url}?{qs}" if "?" in url else f"{url}?{qs}"
        return _do_fetch("GET", url, **kwargs)

    def head(url, **kwargs):
        """
        HEAD 请求。
        部分服务器不支持 HEAD，降级为 GET。
        """
        try:
            return _do_fetch("HEAD", url, **kwargs)
        except HTTPError:
            # HEAD 失败，降级 GET（只关心 headers）
            resp = _do_fetch("GET", url, **kwargs)
            # 语义上 HEAD 只返回 header，不消费 body
            return resp

    def post(url, data=None, json=None, **kwargs):
        """POST 请求"""
        headers = kwargs.get("headers") or {}
        if json is not None:
            headers["Content-Type"] = "application/json"
            kwargs["body"] = json if isinstance(json, str) else json.dumps(json)
        elif data is not None:
            kwargs["body"] = data
        kwargs["headers"] = headers
        return _do_fetch("POST", url, **kwargs)

    def put(url, data=None, **kwargs):
        return _do_fetch("PUT", url, **kwargs)

    def delete(url, **kwargs):
        return _do_fetch("DELETE", url, **kwargs)

    def patch(url, data=None, **kwargs):
        return _do_fetch("PATCH", url, **kwargs)

    def options(url, **kwargs):
        return _do_fetch("OPTIONS", url, **kwargs)

    # Session
    class Session:
        """模拟 requests.Session"""

        def __init__(self):
            self.headers = {}
            self.auth = None
            self.proxies = {}

        def get(self, url, **kw):
            merged = dict(kw)
            merged_headers = {**self.headers, **merged.get("headers", {})}
            merged["headers"] = merged_headers
            return get(url, **merged)

        def head(self, url, **kw):
            return head(url, **kw)

        def post(self, url, **kw):
            return post(url, **kw)

        def request(self, method, url, **kw):
            method_map = {"GET": get, "HEAD": head, "POST": post, "PUT": put, "DELETE": delete}
            fn = method_map.get(method.upper(), get)
            return fn(url, **kw)

        def close(self):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            self.close()

    fake_requests.get = get
    fake_requests.head = head
    fake_requests.post = post
    fake_requests.put = put
    fake_requests.delete = delete
    fake_requests.patch = patch
    fake_requests.options = options
    fake_requests.Session = Session
    fake_requests.Response = _FakeResponse
    fake_requests.codes = types.SimpleNamespace(
        ok=200, created=201, no_content=204,
        bad_request=400, not_found=404, server_error=500
    )

    # 注入 sys.modules
    sys.modules["requests"] = fake_requests
    sys.modules["requests.exceptions"] = exc_mod


# 执行注入
_install_fake_requests()

# ============================================================
# §3 Monkey-patch resolve_project_path
# ============================================================

import dovetail.utils.resource as _resource_mod


def _patched_resolve_project_path(relative):
    """强制以 /dovetail-project 为根"""
    return _PROJECT_ROOT / relative


_resource_mod.resolve_project_path = _patched_resolve_project_path
_resource_mod.project_root = _PROJECT_ROOT

# ============================================================
# §4 确保缓存目录存在
# ============================================================

_lark_cache = _PROJECT_ROOT / ".lark_cache"
_lark_cache.mkdir(parents=True, exist_ok=True)

_dl_cache = _PROJECT_ROOT / ".cache"
_dl_cache.mkdir(parents=True, exist_ok=True)

# ============================================================
# §5 禁用线程化日志 + 降低日志级别
# ============================================================

from dovetail.utils.logger import ThreadSafeLogger

ThreadSafeLogger.DISABLED = True

# ============================================================
# §6 核心编译桥接
# ============================================================

from dovetail.core.compile_config import CompileConfig
from dovetail.core.enums.minecraft import MinecraftVersion
from dovetail.core.enums.optimization import OptimizationLevel
from dovetail.core.errors import CompilationError, report_count
from dovetail.utils.naming import NameDecorator
from dovetail.plugins.plugin_loader.loader import plugin_loader
from dovetail.core.backend import BackendFactory

# 插件单次加载标记
_plugin_loaded = False


def _ensure_plugins():
    """确保插件系统已初始化（只执行一次）"""
    global _plugin_loaded
    if not _plugin_loaded:
        # 加载优化 pass 使 BackendFactory 有可用后端
        import dovetail.core.optimize.passes  # noqa: F401
        plugin_loader.load_plugin("plugin_loader")
        _plugin_loaded = True


def compile_online(
        code: str,
        namespace: str = "demo",
        mc_version: str = "1.21.5",
        opt_level: int = 2,
        recursion: bool = False,
        experimental: bool = False,
        debug: bool = False,
        no_generate: bool = False,
) -> dict:
    """
    在线编译入口 —— JS 端唯一需要调用的编译函数。

    Args:
        code:          用户输入的 .mcdl 源代码
        namespace:     数据包命名空间
        mc_version:    Minecraft 版本号
        opt_level:     优化级别 0-3
        recursion:     启用递归
        experimental:  启用实验性功能
        debug:         调试模式（输出 IR）
        no_generate:   不生成指令（仅解析 + 优化）

    Returns:
        {
            "success": bool,
            "log": str,                          # 编译过程日志
            "errors": [str, ...],                # 错误信息列表
            "output_files": {"path": "content"}  # 生成的文件
        }
    """
    source_path = _workspace / "input.mcdl"
    target_path = _workspace / "target"

    # 写入用户代码到虚拟文件系统
    source_path.write_text(code, encoding='utf-8')

    # 清理旧输出
    if target_path.exists():
        shutil.rmtree(target_path)
    target_path.mkdir(parents=True, exist_ok=True)

    # 重置错误计数器
    report_count.current = 0

    # 日志捕获
    log_capture = io.StringIO()

    result = {
        "success": False,
        "log": "",
        "errors": [],
        "output_files": {}
    }

    try:
        _ensure_plugins()
        NameDecorator.enable = True

        config = CompileConfig(
            namespace=namespace,
            optimization_level=OptimizationLevel(opt_level),
            version=MinecraftVersion.instance(mc_version),
            debug=debug,
            recursion=recursion,
            first_class_functions=False,
            disable_deprecated_function=False,
            experimental=experimental,
            lib_path=_PROJECT_ROOT / "lib",
            description="Dovetail Online IDE"
        )

        from main import Compiler
        compiler = Compiler(
            config,
            generate=not no_generate
        )

        with redirect_stdout(log_capture), redirect_stderr(log_capture):
            exit_code = compiler.compile(source_path, target_path)

        result["success"] = (exit_code == 0)
        result["log"] = log_capture.getvalue()
        if exit_code:
            result["errors"].append(f"Exit code: {exit_code}")

        if result["success"]:
            result["output_files"] = _collect_output_files(target_path)

    except CompilationError as e:
        result["errors"].append(str(e))
        result["log"] = log_capture.getvalue()
    except Exception as e:
        result["errors"].append(f"Internal error: {e}")
        result["log"] = log_capture.getvalue() + "\n" + traceback.format_exc()

    return result


def _collect_output_files(target_path: Path) -> dict:
    """递归收集输出目录中所有文件，返回 {相对路径: 文本内容}"""
    files = {}
    if not target_path.exists():
        return files

    for f in sorted(target_path.rglob("*")):
        if not f.is_file():
            continue
        rel = str(f.relative_to(target_path))
        try:
            files[rel] = f.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            # 二进制文件用 base64 前缀标记
            files[rel] = "base64:" + base64.b64encode(f.read_bytes()).decode()

    return files


def pack_output_zip() -> str:
    """
    将 /workspace/target 打包为 zip 数据包，返回 base64 编码。
    JS 端 atob() 解码后触发浏览器下载。
    """
    buf = io.BytesIO()
    target = _workspace / "target" / "demo"

    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(target.rglob("*")):
            if f.is_file():
                zf.write(f, f.relative_to(target))

    return base64.b64encode(buf.getvalue()).decode()


def get_version_info() -> dict:
    """
    返回编译器版本信息。
    可在页面加载时调用，展示在 UI 上。
    """
    from dovetail.core.config import (
        PROJECT_NAME, PROJECT_VERSION,
        PROJECT_WEBSITE, PROJECT_LICENSE, COMMIT_HASH
    )

    info = {
        "name": PROJECT_NAME,
        "version": PROJECT_VERSION,
        "website": PROJECT_WEBSITE,
        "license": PROJECT_LICENSE,
        "commit": COMMIT_HASH,
        "backends": [],
        "optimization_passes": [],
    }

    try:
        _ensure_plugins()
        from dovetail.core.optimize.pass_registry import get_registry

        if not BackendFactory.is_empty():
            info["backends"] = BackendFactory.get_available_backends()

        registry = get_registry()
        if registry.get_all():
            for pass_class in registry.get_all().values():
                metadata = pass_class.get_metadata()
                info["optimization_passes"].append({
                    "name": metadata.name,
                    "display_name": metadata.display_name,
                    "phase": str(metadata.phase),
                })
    except Exception:
        pass

    return info


def get_available_mc_versions() -> list[str]:
    """返回支持的 Minecraft 版本列表"""
    try:
        from dovetail.core.enums.minecraft import MinecraftVersion
        return [str(v) for v in MinecraftVersion]
    except Exception:
        return ["1.21.5"]
