# coding=utf-8
"""
注解协调器模块

负责注解提取、上下文构建、参数校验和两阶段处理流程。
"""
from __future__ import annotations

from typing import Any

from lark.tree import Meta

from dovetail.core.annotations import get_registry, AnnotationContext
from dovetail.core.annotations.base import AnnotationTarget
from dovetail.core.annotations.category import AnnotationCategory
from dovetail.core.annotations.spec import Annotation
from dovetail.core.compile_config import CompileConfig
from dovetail.core.parser.components.error_reporter import ErrorReporter
from dovetail.core.parser.components.symbol_resolver import SymbolResolver
from dovetail.core.symbols import Symbol, Function
from dovetail.core.symbols.base import Annotatable

UNDEFINED_ANNOTATION = Annotation("undefined", {}, AnnotationCategory.METADATA)

class AnnotationCoordinator:
    """注解协调器 - 管理注解的提取、校验和两阶段处理"""

    def __init__(
            self,
            config: CompileConfig,
            error_reporter: ErrorReporter,
            symbol_resolver: SymbolResolver
    ):
        self.config = config
        self.error_reporter = error_reporter
        self.symbol_resolver = symbol_resolver

    # ==================== 上下文构建 ====================

    def make_context(
            self,
            name: str,
            symbol: Symbol | None,
            target: AnnotationTarget,
            meta: Meta
    ) -> AnnotationContext:
        """
        构建注解处理上下文

        Args:
            name: 符号名
            symbol: 符号对象（PRE_SYMBOL 阶段可能为 None）
            target: 注解目标（FUNCTION / CLASS 等）
            meta: AST 元数据

        Returns:
            AnnotationContext 实例
        """
        return AnnotationContext(
            config=self.config,
            error_reporter=self.error_reporter,
            meta=meta,
            symbol_name=name,
            symbol=symbol,  # noqa
            symbol_target=target,
            symbol_resolver=self.symbol_resolver,
        )

    # ==================== 两阶段处理流程 ====================

    def process_pre(
            self,
            raw_annotations: dict[Annotation, dict[str, Any]],
            name: str,
            target: AnnotationTarget,
            meta: Meta
    ) -> tuple[Any, AnnotationContext]:
        """
        PRE_SYMBOL 阶段：符号还未创建，注解可以先做跳过等决策。

        Args:
            raw_annotations: 提取到的注解字典
            name: 符号名
            target: 注解目标类型
            meta: 元数据

        Returns:
            (pre_result, ctx)  ctx 会被复用给 process_post
        """
        if not raw_annotations:
            return None, None

        ctx = self.make_context(name=name, symbol=None, target=target, meta=meta)
        pre = get_registry().process_pre(raw_annotations, ctx)
        return pre, ctx

    def process_post(
            self,
            raw_annotations: dict[Annotation, dict[str, Any]],
            pre_ctx: AnnotationContext,
            symbol: Annotatable
    ) -> Any:
        """
        POST_SYMBOL 阶段：符号已创建，注解可以修改符号属性。

        会自动给符号应用处理结果

        Args:
            raw_annotations: 提取到的注解字典
            pre_ctx: PRE_SYMBOL 阶段的上下文
            symbol: 已创建的符号对象

        Returns:
            post_result（含 attachments、merged 等）
        """
        if not raw_annotations:
            return None

        pre_ctx.symbol = symbol  # noqa
        post = get_registry().process_post(raw_annotations, pre_ctx)

        if post.merged.type_override and isinstance(symbol, Function):
            symbol.func_type = post.merged.type_override

        if post:
            symbol.annotations.update(post.attachments)
        return post
